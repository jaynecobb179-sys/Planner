package app.planner

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import android.provider.CalendarContract.Calendars
import android.provider.CalendarContract.Events
import android.provider.CalendarContract.Instances
import android.provider.CalendarContract.Reminders
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

object Cal {
    fun has(ctx: Context): Boolean =
        listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR).all {
            ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun writableCalendarId(): Long? {
        Store.app.contentResolver.query(
            Calendars.CONTENT_URI, arrayOf(Calendars._ID),
            "${Calendars.VISIBLE}=1 AND ${Calendars.CALENDAR_ACCESS_LEVEL}>=${Calendars.CAL_ACCESS_CONTRIBUTOR}",
            null, "${Calendars.IS_PRIMARY} DESC"
        )?.use { cur -> if (cur.moveToFirst()) return cur.getLong(0) }
        return null
    }

    /** Задача с датой и временем → событие в календаре (создаёт или обновляет). */
    fun push(t: Task): Task {
        if (t.source == "calendar" || !has(Store.app)) return t
        val cr = Store.app.contentResolver
        val evId = t.calendarEventId
        if (t.date == null || t.time == null || t.done) {
            if (evId != null) {
                cr.delete(ContentUris.withAppendedId(Events.CONTENT_URI, evId), null, null)
                return t.copy(calendarEventId = null)
            }
            return t
        }
        if (!Store.bool("cal_write", true)) return t
        val zone = ZoneId.systemDefault()
        val start = LocalDateTime.of(LocalDate.parse(t.date), LocalTime.parse(t.time))
            .atZone(zone).toInstant().toEpochMilli()
        val v = ContentValues().apply {
            put(Events.DTSTART, start)
            put(Events.DTEND, start + 30 * 60 * 1000L)
            put(Events.TITLE, t.title)
            put(Events.DESCRIPTION, t.notes)
            put(Events.EVENT_TIMEZONE, zone.id)
            put(Events.HAS_ALARM, 1)
        }
        if (evId != null) {
            cr.update(ContentUris.withAppendedId(Events.CONTENT_URI, evId), v, null, null)
            return t
        }
        val cid = writableCalendarId() ?: return t
        v.put(Events.CALENDAR_ID, cid)
        val uri = cr.insert(Events.CONTENT_URI, v) ?: return t
        val id = ContentUris.parseId(uri)
        cr.insert(Reminders.CONTENT_URI, ContentValues().apply {
            put(Reminders.EVENT_ID, id)
            put(Reminders.MINUTES, 10)
            put(Reminders.METHOD, Reminders.METHOD_ALERT)
        })
        return t.copy(calendarEventId = id)
    }

    fun remove(t: Task) {
        val id = t.calendarEventId ?: return
        if (t.source == "calendar" || !has(Store.app)) return
        Store.app.contentResolver.delete(ContentUris.withAppendedId(Events.CONTENT_URI, id), null, null)
    }

    /** События календаря на 14 дней вперёд → задачи планировщика. Возвращает число новых. */
    fun pull(): Int {
        val zone = ZoneId.systemDefault()
        val from = LocalDate.now().atStartOfDay(zone).toInstant().toEpochMilli()
        val to = from + 14L * 24 * 3600 * 1000
        val b = Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, from)
        ContentUris.appendId(b, to)
        val hhmm = DateTimeFormatter.ofPattern("HH:mm")
        var n = 0
        Store.app.contentResolver.query(
            b.build(),
            arrayOf(Instances.EVENT_ID, Instances.TITLE, Instances.BEGIN, Instances.ALL_DAY, Instances.DESCRIPTION),
            null, null, "${Instances.BEGIN} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val eid = c.getLong(0)
                val title = c.getString(1)
                if (title.isNullOrBlank()) continue
                val begin = c.getLong(2)
                val date: String
                val time: String?
                if (c.getInt(3) == 1) {
                    date = Instant.ofEpochMilli(begin).atZone(ZoneOffset.UTC).toLocalDate().toString()
                    time = null
                } else {
                    val z = Instant.ofEpochMilli(begin).atZone(zone)
                    date = z.toLocalDate().toString()
                    time = z.toLocalTime().format(hhmm)
                }
                if (Store.tasks.any { it.calendarEventId == eid && it.date == date }) continue
                Store.upsert(
                    Task(
                        title = title, notes = c.getString(4) ?: "", date = date, time = time,
                        source = "calendar", calendarEventId = eid
                    )
                )
                n++
            }
        }
        return n
    }
}
