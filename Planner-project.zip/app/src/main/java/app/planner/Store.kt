package app.planner

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class PlannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val date: String? = null,      // yyyy-MM-dd; null = лежит в Куче
    val time: String? = null,      // HH:mm
    val category: String? = null,
    val done: Boolean = false,
    val source: String = "manual", // manual | voice | telegram | telegram-voice | calendar | share
    val calendarEventId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

fun JSONObject.optStr(k: String): String? =
    if (has(k) && !isNull(k)) getString(k).takeIf { it.isNotBlank() && it != "null" } else null

object Store {
    lateinit var app: Context
    lateinit var prefs: SharedPreferences
    val tasks = mutableStateListOf<Task>()
    private var inited = false

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("planner", Context.MODE_PRIVATE)
        load()
        inited = true
    }

    // ---- настройки ----
    fun str(k: String, d: String = ""): String = prefs.getString(k, d) ?: d
    fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()
    fun bool(k: String, d: Boolean = false): Boolean = prefs.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) = prefs.edit().putBoolean(k, v).apply()

    // ---- хранение задач в JSON-файле ----
    private val file get() = File(app.filesDir, "tasks.json")

    private fun load() {
        try {
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                tasks.add(
                    Task(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        notes = o.optString("notes", ""),
                        date = o.optStr("date"),
                        time = o.optStr("time"),
                        category = o.optStr("category"),
                        done = o.optBoolean("done", false),
                        source = o.optString("source", "manual"),
                        calendarEventId = if (o.has("cal")) o.getLong("cal") else null,
                        createdAt = o.optLong("created", 0L)
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun save() {
        val arr = JSONArray()
        tasks.forEach { t ->
            val o = JSONObject()
                .put("id", t.id).put("title", t.title).put("notes", t.notes)
                .put("done", t.done).put("source", t.source).put("created", t.createdAt)
            t.date?.let { o.put("date", it) }
            t.time?.let { o.put("time", it) }
            t.category?.let { o.put("category", it) }
            t.calendarEventId?.let { o.put("cal", it) }
            arr.put(o)
        }
        file.writeText(arr.toString())
    }

    @Synchronized
    fun upsert(t: Task) {
        val i = tasks.indexOfFirst { it.id == t.id }
        if (i >= 0) tasks[i] = t else tasks.add(0, t)
        save()
    }

    @Synchronized
    fun delete(id: String) {
        tasks.removeAll { it.id == id }
        save()
    }
}

object Planner {
    fun update(t: Task) {
        val x = try { Cal.push(t) } catch (_: Exception) { t }
        Store.upsert(x)
    }

    fun delete(t: Task) {
        try { Cal.remove(t) } catch (_: Exception) {}
        Store.delete(t.id)
    }

    /** Превращает входящий текст в задачу(и). Возвращает, сколько задач добавлено. */
    fun addFromText(text: String, source: String): Int {
        val clean = text.trim()
        if (clean.isEmpty()) return 0
        if (Ai.enabled()) {
            try {
                val list = Ai.parse(clean)
                if (list.isNotEmpty()) {
                    list.forEach {
                        update(
                            Task(
                                title = it.title, notes = it.notes, date = it.date,
                                time = it.time, category = it.category, source = source
                            )
                        )
                    }
                    return list.size
                }
            } catch (_: Exception) {
            }
        }
        // Без ИИ (или если ИИ недоступен): простой локальный разбор «завтра в 15:00»
        val p = LocalParse.parse(clean)
        val long = p.title.length > 140
        update(
            Task(
                title = if (long) p.title.take(140).trimEnd() + "…" else p.title,
                notes = if (long) clean else p.notes,
                date = p.date, time = p.time, category = p.category, source = source
            )
        )
        return 1
    }
}
