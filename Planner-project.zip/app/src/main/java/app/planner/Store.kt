package app.planner

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class PlannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Remind.schedule(this)
    }
}

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val date: String? = null,      // yyyy-MM-dd; null = лежит в Туче. У повторяющихся — дата первого срабатывания
    val time: String? = null,      // HH:mm
    val category: String? = null,
    val done: Boolean = false,
    val source: String = "manual", // manual | voice | telegram | telegram-voice | calendar | share
    val calendarEventId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val repeat: String? = null,    // правило повторения, см. Rep
    val doneOn: List<String> = emptyList() // для повторяющихся: даты, где отмечено выполненным
)

fun JSONObject.optStr(k: String): String? =
    if (has(k) && !isNull(k)) getString(k).takeIf { it.isNotBlank() && it != "null" } else null

object Store {
    lateinit var app: Context
    lateinit var prefs: SharedPreferences
    val tasks = mutableStateListOf<Task>()
    private var inited = false

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("planner", Context.MODE_PRIVATE)
        load()
        inited = true
    }

    // ---- настройки ----
    fun str(k: String, d: String = ""): String = prefs.getString(k, d) ?: d
    fun put(k: String, v: String) {
        prefs.edit().putString(k, v).apply()
        if (k.startsWith("tg_")) Remind.schedule(app)
    }
    fun bool(k: String, d: Boolean = false): Boolean = prefs.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) {
        prefs.edit().putBoolean(k, v).apply()
        if (k.startsWith("tg_")) Remind.schedule(app)
    }

    // ---- выборки ----
    /** Задачи, которые приходятся на дату d (включая срабатывания повторяющихся). */
    fun on(d: LocalDate): List<Task> {
        val ds = d.toString()
        return tasks.filter { t ->
            val r = t.repeat
            if (r != null) {
                val st = t.date?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                st != null && Rep.occursOn(r, st, d)
            } else t.date == ds
        }
    }

    fun isDone(t: Task, ds: String): Boolean = if (t.repeat != null) t.doneOn.contains(ds) else t.done

    // ---- хранение задач в JSON-файле ----
    private val file get() = File(app.filesDir, "tasks.json")

    private fun load() {
        try {
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val done = mutableListOf<String>()
                o.optJSONArray("doneOn")?.let { a -> for (j in 0 until a.length()) done.add(a.getString(j)) }
                tasks.add(
                    Task(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        notes = o.optString("notes", ""),
                        date = o.optStr("date"),
                        time = o.optStr("time"),
                        category = o.optStr("category"),
                        done = o.optBoolean("done", false),
                        source = o.optString("source", "manual"),
                        calendarEventId = if (o.has("cal")) o.getLong("cal") else null,
                        createdAt = o.optLong("created", 0L),
                        repeat = o.optStr("repeat"),
                        doneOn = done
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun save() {
        val arr = JSONArray()
        tasks.forEach { t ->
            val o = JSONObject()
                .put("id", t.id).put("title", t.title).put("notes", t.notes)
                .put("done", t.done).put("source", t.source).put("created", t.createdAt)
            t.date?.let { o.put("date", it) }
            t.time?.let { o.put("time", it) }
            t.category?.let { o.put("category", it) }
            t.calendarEventId?.let { o.put("cal", it) }
            t.repeat?.let { o.put("repeat", it) }
            if (t.doneOn.isNotEmpty()) o.put("doneOn", JSONArray(t.doneOn))
            arr.put(o)
        }
        file.writeText(arr.toString())
    }

    @Synchronized
    fun upsert(t: Task) {
        val i = tasks.indexOfFirst { it.id == t.id }
        if (i >= 0) tasks[i] = t else tasks.add(0, t)
        save()
        Remind.schedule(app)
    }

    @Synchronized
    fun delete(id: String) {
        tasks.removeAll { it.id == id }
        save()
        Remind.schedule(app)
    }
}

object Planner {
    fun update(t: Task) {
        val x = try { Cal.push(t) } catch (_: Exception) { t }
        Store.upsert(x)
    }

    /** Удаление. У повторяющейся задачи пропадают все повторы (и событие в календаре). */
    fun delete(t: Task) {
        try { Cal.remove(t) } catch (_: Exception) {}
        Store.delete(t.id)
    }

    /** Отметка выполнения. У повторяющейся — только для конкретной даты. */
    fun setDone(t: Task, date: String?, v: Boolean) {
        if (t.repeat != null && date != null) {
            val list = if (v) (t.doneOn + date).distinct().takeLast(400) else t.doneOn - date
            update(t.copy(doneOn = list))
        } else update(t.copy(done = v))
    }

    fun describe(t: Task): String {
        val parts = mutableListOf<String>()
        t.date?.let { d ->
            parts.add(LocalDate.parse(d).format(DateTimeFormatter.ofPattern("d MMMM", Locale("ru"))))
        }
        t.time?.let { parts.add(it) }
        t.repeat?.let { parts.add("🔁 " + Rep.label(it)) }
        return t.title + if (parts.isEmpty()) " (в Туче)" else " — " + parts.joinToString(", ")
    }

    fun addFromText(text: String, source: String): Int = addFromTextDetailed(text, source).size

    /** Превращает входящий текст в задачу(и) и возвращает созданные задачи. */
    fun addFromTextDetailed(text: String, source: String): List<Task> {
        val clean = text.trim()
        if (clean.isEmpty()) return emptyList()
        val created = mutableListOf<Task>()
        fun add(t: Task) {
            update(t)
            created.add(t)
        }
        if (Ai.enabled()) {
            try {
                val list = Ai.parse(clean)
                if (list.isNotEmpty()) {
                    // страховка: правила повторения и явные даты из текста разбираются локально и надёжнее
                    val loc = if (list.size == 1) LocalParse.parse(clean) else null
                    val locRep = loc?.repeat
                    val locDate = loc?.date
                    val locTime = loc?.time
                    list.forEach { p ->
                        var d = p.date
                        var tm = p.time
                        var rep: String? = p.repeat
                        if (locRep != null) {
                            rep = locRep
                            d = locDate
                            tm = locTime ?: tm
                        } else if (rep != null) {
                            val from = d?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
                            d = Rep.firstFrom(rep, from).toString()
                        } else if (locDate != null) {
                            val old = d
                            val past = old != null &&
                                runCatching { LocalDate.parse(old).isBefore(LocalDate.now()) }.getOrDefault(false)
                            if (d == null || past) {
                                d = locDate
                                tm = locTime ?: tm
                            }
                        }
                        add(
                            Task(
                                title = p.title, notes = p.notes, date = d, time = tm,
                                category = p.category, source = source, repeat = rep
                            )
                        )
                    }
                    return created
                }
            } catch (_: Exception) {
            }
        }
        // Без ИИ (или если ИИ недоступен): локальный разбор «каждую пятницу», «1 ноября в 15:00»
        val p = LocalParse.parse(clean)
        val long = p.title.length > 140
        add(
            Task(
                title = if (long) p.title.take(140).trimEnd() + "…" else p.title,
                notes = if (long) clean else p.notes,
                date = p.date, time = p.time, category = p.category, source = source, repeat = p.repeat
            )
        )
        return created
    }
}
