package app.planner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SyncWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        Store.init(applicationContext)
        if (Store.str("tg_token").isBlank()) return Result.success()
        try {
            withContext(Dispatchers.IO) { Tg.sync() }
        } catch (_: Exception) {
        }
        return Result.success()
    }
}
