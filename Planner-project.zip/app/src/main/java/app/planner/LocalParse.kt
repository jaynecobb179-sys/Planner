package app.planner

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Простой разбор русских дат и времени без ИИ и интернета. */
object LocalParse {
    private val IC = RegexOption.IGNORE_CASE
    private val RU = Locale("ru")
    private fun norm(w: String) = w.lowercase(RU).replace('ё', 'е')
    private fun word(w: String) = Regex("(?<![\\p{L}])$w(?![\\p{L}])", IC)

    private val months = listOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val monthAlt = months.joinToString("|")

    private val ordinals = mapOf(
        "первого" to 1, "второго" to 2, "третьего" to 3, "четвертого" to 4, "пятого" to 5,
        "шестого" to 6, "седьмого" to 7, "восьмого" to 8, "девятого" to 9, "десятого" to 10,
        "одиннадцатого" to 11, "двенадцатого" to 12, "тринадцатого" to 13, "четырнадцатого" to 14,
        "пятнадцатого" to 15, "шестнадцатого" to 16, "семнадцатого" to 17, "восемнадцатого" to 18,
        "девятнадцатого" to 19, "двадцатого" to 20, "тридцатого" to 30
    )
    private val unitWords = "первого|второго|третьего|четвертого|четвёртого|пятого|шестого|седьмого|восьмого|девятого"
    private val ordAlt = ordinals.keys.joinToString("|") + "|четвёртого"

    // «в 15:00», «в 16 часов», «в 3 дня», «в 11» (но не «в 12 ноября»)
    private val timeRe = Regex(
        "(?<![\\p{L}\\d])(?:в|к)\\s+(\\d{1,2})(?!\\s*(?:$monthAlt))(?:[:.](\\d{2}))?(\\s*час(?:ов|а)?)?(?:\\s*(дня|вечера|утра|ночи))?(?![\\d\\p{L}])", IC
    )
    private val weekdayRe = Regex(
        "(?<![\\p{L}])(?:в|во)\\s+(понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)(?![\\p{L}])", IC
    )
    // «1 ноября», «26 октября 2027», «первого ноября», «двадцать первого октября»
    private val monthDateRe = Regex(
        "(?<![\\p{L}\\d])(?:(\\d{1,2})|(двадцать|тридцать)\\s+($unitWords)|($ordAlt))\\s+($monthAlt)(?:\\s+(\\d{4}))?(?![\\p{L}\\d])", IC
    )
    private val numDateRe = Regex("(?<![\\d.])(\\d{1,2})\\.(\\d{2})(?:\\.(\\d{2,4}))?(?![\\d])")
    private val days = listOf(
        "понедельник" to DayOfWeek.MONDAY, "вторник" to DayOfWeek.TUESDAY, "среду" to DayOfWeek.WEDNESDAY,
        "четверг" to DayOfWeek.THURSDAY, "пятницу" to DayOfWeek.FRIDAY, "субботу" to DayOfWeek.SATURDAY,
        "воскресенье" to DayOfWeek.SUNDAY
    )

    /** День+месяц(+год) → дата. Если года нет и дата уже прошла — ближайшая будущая (следующий год). */
    private fun resolve(day: Int, mon: Int, year: Int?): LocalDate? {
        if (day !in 1..31 || mon !in 1..12) return null
        if (year != null) return runCatching { LocalDate.of(year, mon, day) }.getOrNull()
        val today = LocalDate.now()
        for (y in today.year..today.year + 4) {
            val d = runCatching { LocalDate.of(y, mon, day) }.getOrNull()
            if (d != null && !d.isBefore(today)) return d
        }
        return null
    }

    private fun dayOf(m: MatchResult): Int = when {
        m.groupValues[1].isNotEmpty() -> m.groupValues[1].toInt()
        m.groupValues[2].isNotEmpty() ->
            (if (norm(m.groupValues[2]) == "двадцать") 20 else 30) + (ordinals[norm(m.groupValues[3])] ?: 0)
        else -> ordinals[norm(m.groupValues[4])] ?: 0
    }

    private fun findExplicit(s: String): Pair<LocalDate, IntRange>? {
        val m = monthDateRe.find(s)
        if (m != null) {
            val mon = months.indexOf(norm(m.groupValues[5])) + 1
            val ys = m.groupValues[6]
            val d = resolve(dayOf(m), mon, if (ys.isEmpty()) null else ys.toInt())
            if (d != null) return d to m.range
        }
        val n = numDateRe.find(s)
        if (n != null) {
            val ys = n.groupValues[3]
            val year = when {
                ys.isEmpty() -> null
                ys.length == 2 -> 2000 + ys.toInt()
                else -> ys.toInt()
            }
            val d = resolve(n.groupValues[1].toInt(), n.groupValues[2].toInt(), year)
            if (d != null) return d to n.range
        }
        return null
    }

    fun parse(text: String): Ai.Parsed {
        val original = text.trim()
        var s = original
        val today = LocalDate.now()
        var date: LocalDate? = null
        var time: String? = null

        // время
        for (m in timeRe.findAll(s)) {
            var h = m.groupValues[1].toInt()
            val hasMin = m.groupValues[2].isNotEmpty()
            val mm = if (hasMin) m.groupValues[2].toInt() else 0
            val hasHour = m.groupValues[3].isNotEmpty()
            val part = norm(m.groupValues[4])
            if (h > 23 || mm > 59) continue
            if (!hasMin && !hasHour && part.isEmpty() && h < 7) continue   // «в 5 комнате»
            if ((part == "дня" || part == "вечера") && h < 12) h += 12
            time = "%02d:%02d".format(h, mm)
            s = s.removeRange(m.range)
            break
        }

        // дата: сначала явная («1 ноября», 28.10), потом «завтра», «в пятницу»
        fun cut(re: Regex): MatchResult? {
            val m = re.find(s)
            if (m != null) s = s.removeRange(m.range)
            return m
        }
        val ex = findExplicit(s)
        if (ex != null) {
            date = ex.first
            s = s.removeRange(ex.second)
        } else if (cut(word("послезавтра")) != null) date = today.plusDays(2)
        else if (cut(word("завтра")) != null) date = today.plusDays(1)
        else if (cut(word("сегодня")) != null) date = today
        else {
            val w = cut(weekdayRe)
            if (w != null) {
                val dow = days.first { it.first == norm(w.groupValues[1]) }.second
                date = today.with(TemporalAdjusters.next(dow))
            }
        }
        if (time != null && date == null) date = today

        var title = s.replace(Regex("\\s+"), " ").trim().trim(',', '.', ' ', '-', '—', ':')
        if (title.isBlank()) title = original
        title = title.replaceFirstChar { it.uppercase() }
        val notes = if (title != original) original else ""
        return Ai.Parsed(title, notes, date?.toString(), time, null)
    }
}
