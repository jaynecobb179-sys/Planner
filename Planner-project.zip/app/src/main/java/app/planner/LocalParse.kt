package app.planner

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Простой разбор русских дат и времени без ИИ и интернета. */
object LocalParse {
    private val IC = RegexOption.IGNORE_CASE
    private fun word(w: String) = Regex("(?<![\\p{L}])$w(?![\\p{L}])", IC)

    private val timeRe = Regex(
        "(?<![\\p{L}\\d])(?:в|к)\\s+(\\d{1,2})(?:[:.](\\d{2}))?(\\s*час(?:ов|а)?)?(?:\\s*(дня|вечера|утра|ночи))?(?![\\d\\p{L}])", IC
    )
    private val weekdayRe = Regex(
        "(?<![\\p{L}])(?:в|во)\\s+(понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)(?![\\p{L}])", IC
    )
    private val dateRe = Regex("(?<![\\d.])(\\d{1,2})\\.(\\d{2})(?:\\.(\\d{2,4}))?(?![\\d])")
    private val days = listOf(
        "понедельник" to DayOfWeek.MONDAY, "вторник" to DayOfWeek.TUESDAY, "среду" to DayOfWeek.WEDNESDAY,
        "четверг" to DayOfWeek.THURSDAY, "пятницу" to DayOfWeek.FRIDAY, "субботу" to DayOfWeek.SATURDAY,
        "воскресенье" to DayOfWeek.SUNDAY
    )

    fun parse(text: String): Ai.Parsed {
        val original = text.trim()
        var s = original
        val today = LocalDate.now()
        var date: LocalDate? = null
        var time: String? = null

        // время: «в 15:00», «в 16 часов», «в 3 дня», «в 11»
        for (m in timeRe.findAll(s)) {
            var h = m.groupValues[1].toInt()
            val hasMin = m.groupValues[2].isNotEmpty()
            val mm = if (hasMin) m.groupValues[2].toInt() else 0
            val hasHour = m.groupValues[3].isNotEmpty()
            val part = m.groupValues[4].lowercase(Locale("ru"))
            if (h > 23 || mm > 59) continue
            if (!hasMin && !hasHour && part.isEmpty() && h < 7) continue   // «в 5 комнате»
            if ((part == "дня" || part == "вечера") && h < 12) h += 12
            time = "%02d:%02d".format(h, mm)
            s = s.removeRange(m.range)
            break
        }

        // дата: сегодня / завтра / послезавтра / в пятницу / 28.10
        fun cut(re: Regex): MatchResult? {
            val m = re.find(s)
            if (m != null) s = s.removeRange(m.range)
            return m
        }
        if (cut(word("послезавтра")) != null) date = today.plusDays(2)
        else if (cut(word("завтра")) != null) date = today.plusDays(1)
        else if (cut(word("сегодня")) != null) date = today
        else {
            val w = cut(weekdayRe)
            if (w != null) {
                val dow = days.first { it.first == w.groupValues[1].lowercase(Locale("ru")) }.second
                date = today.with(TemporalAdjusters.next(dow))
            } else {
                val d = dateRe.find(s)
                if (d != null) {
                    val day = d.groupValues[1].toInt()
                    val mon = d.groupValues[2].toInt()
                    if (day in 1..31 && mon in 1..12) {
                        val ys = d.groupValues[3]
                        val year = when {
                            ys.isEmpty() -> today.year
                            ys.length == 2 -> 2000 + ys.toInt()
                            else -> ys.toInt()
                        }
                        date = runCatching { LocalDate.of(year, mon, day) }.getOrNull()
                        if (date != null && ys.isEmpty() && date.isBefore(today)) date = date.plusYears(1)
                        if (date != null) s = s.removeRange(d.range)
                    }
                }
            }
        }
        if (time != null && date == null) date = today

        var title = s.replace(Regex("\\s+"), " ").trim().trim(',', '.', ' ', '-', '—')
        if (title.isBlank()) title = original
        title = title.replaceFirstChar { it.uppercase() }
        val notes = if (title != original) original else ""
        return Ai.Parsed(title, notes, date?.toString(), time, null)
    }
}
