package app.planner

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Разбор русских дат, времени и повторений без ИИ и интернета. */
object LocalParse {
    private val IC = RegexOption.IGNORE_CASE
    private val RU = Locale("ru")
    private fun norm(w: String) = w.lowercase(RU).replace('ё', 'е')
    private fun word(w: String) = Regex("(?<![\\p{L}])$w(?![\\p{L}])", IC)

    private val months = listOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val monthAlt = months.joinToString("|")

    // порядковые числительные: первого/первое ... тридцатого/тридцатое
    private val ordStems = listOf(
        "перв" to 1, "втор" to 2, "четверт" to 4, "пят" to 5, "шест" to 6, "седьм" to 7, "восьм" to 8,
        "девят" to 9, "десят" to 10, "одиннадцат" to 11, "двенадцат" to 12, "тринадцат" to 13,
        "четырнадцат" to 14, "пятнадцат" to 15, "шестнадцат" to 16, "семнадцат" to 17,
        "восемнадцат" to 18, "девятнадцат" to 19, "двадцат" to 20, "тридцат" to 30
    )
    private val ordinals: Map<String, Int> = buildMap {
        for ((st, v) in ordStems) { put(st + "ого", v); put(st + "ое", v) }
        put("третьего", 3); put("третье", 3)
    }
    private val ordAlt = ordinals.keys.joinToString("|") + "|четвёртого|четвёртое"
    private val unitWords = ordinals.filter { it.value < 10 }.keys.joinToString("|") + "|четвёртого|четвёртое"

    // «в 15:00», «в 16 часов», «в 3 дня», «в 11» (но не «в 12 ноября»)
    private val timeRe = Regex(
        "(?<![\\p{L}\\d])(?:в|к)\\s+(\\d{1,2})(?!\\s*(?:$monthAlt))(?:[:.](\\d{2}))?(\\s*час(?:ов|а)?)?(?:\\s*(дня|вечера|утра|ночи))?(?![\\d\\p{L}])", IC
    )
    private val weekdayRe = Regex(
        "(?<![\\p{L}])(?:в|во)\\s+(понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)(?![\\p{L}])", IC
    )
    // «1 ноября», «26 октября 2027», «первого ноября», «двадцать первого октября»
    private val monthDateRe = Regex(
        "(?<![\\p{L}\\d])(?:(\\d{1,2})|(двадцать|тридцать)\\s+($unitWords)|($ordAlt))\\s+($monthAlt)(?:\\s+(\\d{4}))?(?![\\p{L}\\d])", IC
    )
    private val numDateRe = Regex("(?<![\\d.])(\\d{1,2})\\.(\\d{2})(?:\\.(\\d{2,4}))?(?![\\d])")
    private val days = listOf(
        "понедельник" to DayOfWeek.MONDAY, "вторник" to DayOfWeek.TUESDAY, "среду" to DayOfWeek.WEDNESDAY,
        "четверг" to DayOfWeek.THURSDAY, "пятницу" to DayOfWeek.FRIDAY, "субботу" to DayOfWeek.SATURDAY,
        "воскресенье" to DayOfWeek.SUNDAY
    )

    // ───────── повторения ─────────
    private val dtRaw = "(?:\\d{1,2}(?:\\s*-?\\s*(?:ое|ого|ым|ом|го|е|й))?|(?:двадцать|тридцать)\\s+(?:$unitWords)|(?:$ordAlt))"
    private val yearlyRe = Regex("(?<![\\p{L}])(?:ежегодн\\w*|кажд\\w*\\s+год\\w*|раз\\s+в\\s+год)(?![\\p{L}])", IC)
    private val lastDayRe = Regex("(?<![\\p{L}])(?:в\\s+)?последн\\w*\\s+(?:день|числ\\w*)\\s+месяц\\w*", IC)
    private val monthlyCueRe = Regex(
        "(?<![\\p{L}])(?:ежемесячн\\w*|кажд\\w*\\s+месяц\\w*|раз\\s+в\\s+месяц|числ\\w*\\s+кажд\\w*\\s+месяц\\w*|кажд\\w*\\s+$dtRaw\\s*числ\\w*)", IC
    )
    private val strongDayRe = Regex("(?<![\\p{L}\\d])$dtRaw\\s*числ\\w*", IC)
    private val suffixDayRe = Regex(
        "(?<![\\p{L}\\d])(?:\\d{1,2}\\s*-\\s*(?:ое|ого|ым|ом|го|е|й)|(?:двадцать|тридцать)\\s+(?:$unitWords)|(?:$ordAlt))(?![\\p{L}\\d])", IC
    )
    private val bareDayRe = Regex("(?<![\\p{L}\\d.:-])\\d{1,2}(?![\\p{L}\\d.:])(?!\\s*(?:$monthAlt))")
    private val intervalRe = Regex(
        "(?<![\\p{L}])(?:кажд\\w*|раз\\s+в)\\s+(\\d{1,2}|два|две|три|четыре|пять|шесть|семь)\\s+(дн\\w*|недел\\w*)", IC
    )
    private val dailyRe = Regex("(?<![\\p{L}])(?:ежедневн\\w*|каждодневн\\w*|кажд\\w*\\s+(?:день|дня)|раз\\s+в\\s+день)(?![\\p{L}])", IC)
    private val weeklyWordRe = Regex("(?<![\\p{L}])(?:еженедельн\\w*|кажд\\w*\\s+недел\\w*|раз\\s+в\\s+недел\\w*)", IC)
    private const val WD = "(?:понедельник(?:ам|а|у|и)?|вторник(?:ам|а|у|и)?|сред(?:ам|а|у|ы)?|четверг(?:ам|а|у|и)?|пятниц(?:ам|а|у|ы)?|суббот(?:ам|а|у|ы)?|воскресень(?:ям|е|я|ю)?)"
    private val wdTokRe = Regex("(?<![\\p{L}])(?:(по|кажд\\w*)\\s+)?($WD)(?![\\p{L}])", IC)
    private val budRe = Regex("(?<![\\p{L}])(?:по|кажд\\w*)\\s+будн\\w*(?:\\s+дн\\w*)?", IC)
    private val vyhRe = Regex("(?<![\\p{L}])(?:по|кажд\\w*)\\s+выходн\\w*(?:\\s+дн\\w*)?", IC)

    private class RepHit(val rule: String, val ranges: List<IntRange>, val dow: Int?)

    private fun wdNum(w: String): Int = when {
        w.startsWith("понедельник") -> 1
        w.startsWith("вторник") -> 2
        w.startsWith("сред") -> 3
        w.startsWith("четверг") -> 4
        w.startsWith("пятниц") -> 5
        w.startsWith("суббот") -> 6
        else -> 7
    }

    private fun numWord(w: String): Int {
        val n = w.lowercase(RU)
        n.toIntOrNull()?.let { return maxOf(it, 1) }
        return when (n) {
            "два", "две" -> 2; "три" -> 3; "четыре" -> 4; "пять" -> 5; "шесть" -> 6; "семь" -> 7
            else -> 1
        }
    }

    private fun dayFromWords(t: String): Int? {
        val n = norm(t)
        Regex("\\d{1,2}").find(n)?.let { return it.value.toInt() }
        Regex("(двадцать|тридцать)\\s+(\\p{L}+)").find(n)?.let { m ->
            val u = ordinals[m.groupValues[2]]
            if (u != null && u < 10) return (if (m.groupValues[1] == "двадцать") 20 else 30) + u
        }
        for ((w, v) in ordinals.entries.sortedByDescending { it.key.length }) if (n.contains(w)) return v
        return null
    }

    /** Число месяца в тексте: «20-го», «двадцатого числа», «25 числа», «каждое 20-е число». */
    private fun findDayTok(s: String): Pair<Int, IntRange>? {
        for (re in listOf(strongDayRe, suffixDayRe, bareDayRe)) {
            for (m in re.findAll(s)) {
                val v = dayFromWords(m.value)
                if (v != null && v in 1..31) return v to m.range
            }
        }
        return null
    }

    private fun findRepeat(s: String): RepHit? {
        val ranges = mutableListOf<IntRange>()

        // раз в год
        val y = yearlyRe.find(s)
        if (y != null) {
            ranges.add(y.range)
            val ex = findExplicit(s)
            val d = ex?.first ?: LocalDate.now()
            if (ex != null) ranges.add(ex.second)
            return RepHit("Y:%02d-%02d".format(d.monthValue, d.dayOfMonth), ranges, null)
        }

        // раз в месяц
        val last = lastDayRe.find(s)
        val mc = monthlyCueRe.find(s)
        if (last != null || mc != null) {
            last?.let { ranges.add(it.range) }
            mc?.let { ranges.add(it.range) }
            if (last != null) return RepHit("M:31", ranges, null)
            val tok = findDayTok(s)
            val day = if (tok != null) {
                ranges.add(tok.second)
                tok.first
            } else (findExplicit(s)?.first ?: LocalDate.now()).dayOfMonth
            return RepHit("M:$day", ranges, null)
        }

        // каждые N дней / недель
        val iv = intervalRe.find(s)
        if (iv != null) {
            ranges.add(iv.range)
            val n = numWord(iv.groupValues[1])
            val weeks = iv.groupValues[2].lowercase(RU).startsWith("недел")
            val total = if (weeks) n * 7 else n
            var dow: Int? = null
            if (weeks) {
                val w = wdTokRe.find(s)
                if (w != null) {
                    dow = wdNum(norm(w.groupValues[2]))
                    ranges.add(w.range)
                }
            }
            return RepHit(if (total <= 1) "D" else "E:$total", ranges, dow)
        }

        // каждый день
        val dl = dailyRe.find(s)
        if (dl != null) return RepHit("D", listOf(dl.range), null)

        // по дням недели
        val wdTokens = wdTokRe.findAll(s).toList()
        val prefixed = wdTokens.any { it.groupValues[1].isNotEmpty() }
        val weeklyWord = weeklyWordRe.find(s)
        val bud = budRe.find(s)
        val vyh = vyhRe.find(s)
        if (weeklyWord != null || bud != null || vyh != null || prefixed) {
            val set = sortedSetOf<Int>()
            for (t in wdTokens) {
                set.add(wdNum(norm(t.groupValues[2])))
                ranges.add(t.range)
            }
            if (bud != null) { set.addAll(1..5); ranges.add(bud.range) }
            if (vyh != null) { set.addAll(6..7); ranges.add(vyh.range) }
            weeklyWord?.let { ranges.add(it.range) }
            if (set.isEmpty()) {
                val base = findExplicit(s)?.first ?: LocalDate.now()
                set.add(base.dayOfWeek.value)
            }
            return RepHit("W:" + set.joinToString(","), ranges, null)
        }
        return null
    }

    private fun removeRanges(s: String, ranges: List<IntRange>): String {
        if (ranges.isEmpty()) return s
        val merged = mutableListOf<IntRange>()
        for (r in ranges.sortedBy { it.first }) {
            val l = merged.lastOrNull()
            if (l != null && r.first <= l.last + 1) merged[merged.size - 1] = l.first..maxOf(l.last, r.last)
            else merged.add(r)
        }
        var out = s
        for (r in merged.reversed()) out = out.removeRange(r)
        return out
    }

    // ───────── даты ─────────
    /** День+месяц(+год) → дата. Без года и если дата прошла — ближайшая будущая (следующий год). */
    private fun resolve(day: Int, mon: Int, year: Int?): LocalDate? {
        if (day !in 1..31 || mon !in 1..12) return null
        if (year != null) return runCatching { LocalDate.of(year, mon, day) }.getOrNull()
        val today = LocalDate.now()
        for (y in today.year..today.year + 4) {
            val d = runCatching { LocalDate.of(y, mon, day) }.getOrNull()
            if (d != null && !d.isBefore(today)) return d
        }
        return null
    }

    private fun dayOf(m: MatchResult): Int = when {
        m.groupValues[1].isNotEmpty() -> m.groupValues[1].toInt()
        m.groupValues[2].isNotEmpty() ->
            (if (norm(m.groupValues[2]) == "двадцать") 20 else 30) + (ordinals[norm(m.groupValues[3])] ?: 0)
        else -> ordinals[norm(m.groupValues[4])] ?: 0
    }

    private fun findExplicit(s: String): Pair<LocalDate, IntRange>? {
        val m = monthDateRe.find(s)
        if (m != null) {
            val mon = months.indexOf(norm(m.groupValues[5])) + 1
            val ys = m.groupValues[6]
            val d = resolve(dayOf(m), mon, if (ys.isEmpty()) null else ys.toInt())
            if (d != null) return d to m.range
        }
        val n = numDateRe.find(s)
        if (n != null) {
            val ys = n.groupValues[3]
            val year = when {
                ys.isEmpty() -> null
                ys.length == 2 -> 2000 + ys.toInt()
                else -> ys.toInt()
            }
            val d = resolve(n.groupValues[1].toInt(), n.groupValues[2].toInt(), year)
            if (d != null) return d to n.range
        }
        return null
    }

    fun parse(text: String): Ai.Parsed {
        val original = text.trim()
        var s = original
        val today = LocalDate.now()
        var date: LocalDate? = null
        var time: String? = null

        // время
        for (m in timeRe.findAll(s)) {
            var h = m.groupValues[1].toInt()
            val hasMin = m.groupValues[2].isNotEmpty()
            val mm = if (hasMin) m.groupValues[2].toInt() else 0
            val hasHour = m.groupValues[3].isNotEmpty()
            val part = norm(m.groupValues[4])
            if (h > 23 || mm > 59) continue
            if (!hasMin && !hasHour && part.isEmpty() && h < 7) continue   // «в 5 комнате»
            if ((part == "дня" || part == "вечера") && h < 12) h += 12
            time = "%02d:%02d".format(h, mm)
            s = s.removeRange(m.range)
            break
        }

        // повторение
        val rep = findRepeat(s)
        val rule: String? = rep?.rule
        if (rep != null) s = removeRanges(s, rep.ranges)

        // дата: сначала явная («1 ноября», 28.10), потом «завтра», «в пятницу»
        fun cut(re: Regex): MatchResult? {
            val m = re.find(s)
            if (m != null) s = s.removeRange(m.range)
            return m
        }
        val ex = findExplicit(s)
        if (ex != null) {
            date = ex.first
            s = s.removeRange(ex.second)
        } else if (cut(word("послезавтра")) != null) date = today.plusDays(2)
        else if (cut(word("завтра")) != null) date = today.plusDays(1)
        else if (cut(word("сегодня")) != null) date = today
        else {
            val w = cut(weekdayRe)
            if (w != null) {
                val dow = days.first { it.first == norm(w.groupValues[1]) }.second
                date = today.with(TemporalAdjusters.next(dow))
            }
        }
        if (time != null && date == null) date = today

        // у повторяющейся задачи дата = первое срабатывание
        if (rule != null) {
            var from = date ?: today
            val dw = rep?.dow
            if (dw != null) from = from.with(TemporalAdjusters.nextOrSame(DayOfWeek.of(dw)))
            date = Rep.firstFrom(rule, from)
        }

        var title = s.replace(Regex("\\s+"), " ").trim().trim(',', '.', ' ', '-', '—', ':')
        if (title.isBlank()) title = original
        title = title.replaceFirstChar { it.uppercase() }
        val notes = if (title != original) original else ""
        return Ai.Parsed(title, notes, date?.toString(), time, null, rule)
    }
}
