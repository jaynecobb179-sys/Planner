package app.planner

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tg-sync", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )
        handleIntent(intent)
        setContent { PlannerTheme { App(tick.intValue) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** «Поделиться» из любого приложения → текст попадает в планировщик. */
    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Thread {
            val n = Planner.addFromText(t, "share")
            runOnUiThread { Toast.makeText(this, "Добавлено задач: $n", Toast.LENGTH_SHORT).show() }
        }.start()
    }
}

@Composable
fun PlannerTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    MaterialTheme(colorScheme = scheme, content = content)
}

fun today(): String = LocalDate.now().toString()

suspend fun toast(ctx: Context, s: String) =
    withContext(Dispatchers.Main) { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }

data class SyncResult(val msg: String, val added: Int, val error: Boolean)

/** Telegram + календарь. */
suspend fun fullSync(): SyncResult = withContext(Dispatchers.IO) {
    val parts = mutableListOf<String>()
    var added = 0
    var err = false
    if (Store.str("tg_token").isNotBlank()) {
        try {
            val n = Tg.sync(); added += n; parts.add("Telegram: +$n")
        } catch (e: Exception) {
            err = true; parts.add("Telegram: ошибка (${e.message?.take(80)})")
        }
    }
    if (Cal.has(Store.app)) {
        try {
            val n = Cal.pull(); added += n; parts.add("Календарь: +$n")
        } catch (e: Exception) {
            err = true; parts.add("Календарь: ошибка")
        }
    }
    SyncResult(
        if (parts.isEmpty()) "Подключите бота в настройках и разрешите доступ к календарю" else parts.joinToString("\n"),
        added, err
    )
}

val CAL_PERMS = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Refreshable(busy: Boolean, onRefresh: () -> Unit, content: @Composable () -> Unit) {
    PullToRefreshBox(isRefreshing = busy, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) { content() }
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var creating by remember { mutableStateOf(false) }
    var newDate by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var asked by remember { mutableStateOf(false) }

    val doSync: (Boolean) -> Unit = { manual ->
        if (!busy) scope.launch {
            busy = true
            val r = fullSync()
            busy = false
            if (manual || r.error || r.added > 0) toast(ctx, r.msg)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { doSync(true) }
    val sync: () -> Unit = { if (Cal.has(ctx)) doSync(true) else perm.launch(CAL_PERMS) }
    LaunchedEffect(tick) {
        if (!Cal.has(ctx) && !asked) { asked = true; perm.launch(CAL_PERMS) } else doSync(false)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) {
            scope.launch(Dispatchers.IO) {
                val n = try { Planner.addFromText(text, "voice") } catch (e: Exception) { 0 }
                toast(ctx, if (n > 0) "Добавлено задач: $n" else "Не получилось добавить")
            }
        }
    }
    val startSpeech = {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите задачу")
        try { speech.launch(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "На телефоне нет службы распознавания речи", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val names = listOf("Сегодня", "Неделя", "Туча", "Настройки")
                val icons = listOf("📅", "🗓", "☁️", "⚙️")
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(n, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab < 3) Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SmallFloatingActionButton(onClick = { startSpeech() }) { Text("🎤") }
                FloatingActionButton(onClick = {
                    newDate = if (tab < 2) today() else null
                    creating = true
                }) { Text("+", fontSize = 28.sp) }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> Refreshable(busy, sync) { TodayScreen(busy, sync) { editing = it } }
                1 -> Refreshable(busy, sync) {
                    WeekScreen(onEdit = { editing = it }, onAdd = { d -> newDate = d; creating = true })
                }
                2 -> Refreshable(busy, sync) { HeapScreen { editing = it } }
                else -> SettingsScreen()
            }
        }
    }

    if (creating) TaskDialog(null, newDate) { creating = false }
    editing?.let { t -> TaskDialog(t, null) { editing = null } }
}

@Composable
fun SectionTitle(s: String) = Text(
    s, Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary
)

fun srcLabel(s: String): String? = when (s) {
    "telegram" -> "✈️ Telegram"
    "telegram-voice" -> "✈️🎤 голосовое"
    "voice" -> "🎤 голос"
    "calendar" -> "📆 календарь"
    "share" -> "↗ из приложения"
    else -> null
}

@Composable
fun TaskRow(t: Task, onEdit: () -> Unit, extra: @Composable (() -> Unit)? = null) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onEdit)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = t.done, onCheckedChange = { Planner.update(t.copy(done = it)) })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title, style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null
                )
                val meta = listOfNotNull(t.time, t.category, srcLabel(t.source)).joinToString(" · ")
                if (meta.isNotBlank()) Text(
                    meta, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            extra?.invoke()
        }
    }
}

@Composable
fun TodayScreen(busy: Boolean, sync: () -> Unit, onEdit: (Task) -> Unit) {
    val td = today()
    val todays = Store.tasks.filter { it.date == td }
        .sortedWith(compareBy<Task>({ it.done }, { it.time ?: "99:99" }))
    val overdue = Store.tasks.filter { val d = it.date; d != null && d < td && !it.done }.sortedBy { it.date }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("ru")))
                            .replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text("Осталось задач: ${todays.count { !it.done }}", style = MaterialTheme.typography.bodyMedium)
                }
                OutlinedButton(onClick = sync, enabled = !busy) { Text(if (busy) "…" else "⟳ Синхр.") }
            }
        }
        if (overdue.isNotEmpty()) {
            item { SectionTitle("Просрочено") }
            items(overdue, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = td)) }) { Text("На сегодня") }
                }
            }
        }
        item { SectionTitle("Сегодня") }
        if (todays.isEmpty()) item {
            Text("На сегодня пусто. Загляните в Тучу.", Modifier.padding(16.dp))
        }
        items(todays, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }) }
    }
}

@Composable
fun HeapScreen(onEdit: (Task) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val td = today()
    val heap = Store.tasks.filter { it.date == null }
    val open = heap.filter { !it.done }
    val groups = open.groupBy { it.category ?: "Без категории" }.entries
        .sortedBy { if (it.key == "Без категории") "\uFFFF" else it.key }
    val done = heap.filter { it.done }
    var busy by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Туча", style = MaterialTheme.typography.headlineSmall)
                    Text("Задач без даты: ${open.size}", style = MaterialTheme.typography.bodyMedium)
                }
                if (Ai.enabled()) OutlinedButton(enabled = !busy, onClick = {
                    scope.launch(Dispatchers.IO) {
                        busy = true
                        try {
                            val todo = open.filter { it.category == null }.take(100)
                            val m = Ai.organize(todo)
                            m.forEach { (id, c) ->
                                Store.tasks.find { it.id == id }?.let { Planner.update(it.copy(category = c)) }
                            }
                            toast(ctx, "Разложено задач: ${m.size}")
                        } catch (e: Exception) {
                            val m = e.message ?: ""
                            toast(ctx, if (m.contains("402")) "ИИ: на балансе API-ключа нет денег. Выберите Groq — он бесплатный" else "ИИ: ${m.take(100)}")
                        }
                        busy = false
                    }
                }) { Text(if (busy) "…" else "🤖 Разобрать") }
            }
        }
        if (open.isEmpty()) item { Text("Туча пуста.", Modifier.padding(16.dp)) }
        groups.forEach { (cat, list) ->
            item(key = "h_$cat") { SectionTitle(cat) }
            items(list, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = td)) }) { Text("Сегодня") }
                }
            }
        }
        if (done.isNotEmpty()) {
            item(key = "h_done") { SectionTitle("Выполнено") }
            items(done, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }) }
        }
    }
}

@Composable
fun DayStrip(d: LocalDate, isOpen: Boolean, onToggle: () -> Unit, onEdit: (Task) -> Unit, onAdd: () -> Unit) {
    val ds = d.toString()
    val list = Store.tasks.filter { it.date == ds }
        .sortedWith(compareBy<Task>({ it.done }, { it.time ?: "99:99" }))
    val ru = Locale("ru")
    val label = d.dayOfWeek.getDisplayName(TextStyle.SHORT, ru).replaceFirstChar { it.uppercase() }.trimEnd('.') +
        ". " + d.format(DateTimeFormatter.ofPattern("dd.MM."))
    val colors = if (d == LocalDate.now()) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    else CardDefaults.cardColors()
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onToggle),
        colors = colors
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(label, Modifier.width(112.dp), style = MaterialTheme.typography.titleMedium)
                Column(Modifier.weight(1f)) {
                    if (list.isEmpty()) Text("Пока задач нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else if (!isOpen) {
                        list.take(3).forEach { t ->
                            Text(
                                listOfNotNull(t.time, t.title).joinToString(" "),
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textDecoration = if (t.done) TextDecoration.LineThrough else null
                            )
                        }
                        if (list.size > 3) Text("и ещё ${list.size - 3}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(if (isOpen) "▲" else "▼")
            }
            if (isOpen) {
                list.forEach { t -> TaskRow(t, { onEdit(t) }) }
                TextButton(onClick = onAdd) { Text("+ Задача на этот день") }
            }
        }
    }
}

@Composable
fun WeekScreen(onEdit: (Task) -> Unit, onAdd: (String) -> Unit) {
    val td = LocalDate.now()
    var offset by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf(setOf(td.toString())) }
    val monday = td.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).plusWeeks(offset.toLong())
    val days = (0..6).map { monday.plusDays(it.toLong()) }
    val f = DateTimeFormatter.ofPattern("d.MM")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { offset-- }) { Text("‹", fontSize = 28.sp) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Неделя", style = MaterialTheme.typography.headlineSmall)
                    Text("${days.first().format(f)} – ${days.last().format(f)}", style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = { offset++ }) { Text("›", fontSize = 28.sp) }
            }
        }
        if (offset != 0) item {
            TextButton(onClick = { offset = 0 }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("К текущей неделе") }
        }
        items(days, key = { it.toString() }) { d ->
            val ds = d.toString()
            DayStrip(
                d, open.contains(ds),
                onToggle = { open = if (open.contains(ds)) open - ds else open + ds },
                onEdit = onEdit, onAdd = { onAdd(ds) }
            )
        }
    }
}

fun pickDate(ctx: Context, cur: String?, set: (String) -> Unit) {
    val d = cur?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    DatePickerDialog(ctx, { _, y, m, day -> set(LocalDate.of(y, m + 1, day).toString()) },
        d.year, d.monthValue - 1, d.dayOfMonth).show()
}

fun pickTime(ctx: Context, set: (String) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> set("%02d:%02d".format(h, m)) }, 9, 0, true).show()
}

@Composable
fun TaskDialog(task: Task?, defaultDate: String?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(task?.title ?: "") }
    var notes by remember { mutableStateOf(task?.notes ?: "") }
    var cat by remember { mutableStateOf(task?.category ?: "") }
    var date by remember { mutableStateOf(task?.date ?: defaultDate) }
    var time by remember { mutableStateOf(task?.time) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (task == null) "Новая задача" else "Задача") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Что сделать") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cat, { cat = it }, label = { Text("Категория") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pickDate(ctx, date) { date = it } }) { Text(date ?: "Дата") }
                    OutlinedButton(onClick = { pickTime(ctx) { time = it } }) { Text(time ?: "Время") }
                    if (date != null || time != null) TextButton(onClick = { date = null; time = null }) { Text("✕") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    val d = date ?: if (time != null) today() else null
                    val base = task ?: Task(title = "")
                    Planner.update(
                        base.copy(
                            title = title.trim(), notes = notes, category = cat.trim().ifBlank { null },
                            date = d, time = if (d == null) null else time
                        )
                    )
                    onClose()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (task != null) TextButton(onClick = { Planner.delete(task); onClose() }) { Text("Удалить") }
                TextButton(onClick = onClose) { Text("Отмена") }
            }
        }
    )
}

// ───────────────────────── Настройки ─────────────────────────
@Composable
fun PrefField(label: String, key: String) {
    var v by remember { mutableStateOf(Store.str(key)) }
    OutlinedTextField(
        v, { v = it; Store.put(key, it.trim()) },
        label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun Choice(title: String, key: String, options: List<Pair<String, String>>, default: String) {
    var cur by remember { mutableStateOf(Store.str(key, default)) }
    Text(title, style = MaterialTheme.typography.bodyMedium)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, l) ->
            FilterChip(selected = cur == v, onClick = { cur = v; Store.put(key, v) }, label = { Text(l) })
        }
    }
}

@Composable
fun PrefSwitch(label: String, key: String, default: Boolean) {
    var on by remember { mutableStateOf(Store.bool(key, default)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { on = it; Store.putBool(key, it) })
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineSmall)

        SectionTitle("Telegram-бот")
        PrefField("Токен бота (от @BotFather)", "tg_token")
        PrefField("Chat ID (заполнится после первого сообщения боту)", "tg_chat")
        Button(onClick = { scope.launch { toast(ctx, fullSync().msg) } }) { Text("Проверить и забрать сообщения") }

        SectionTitle("Расшифровка голосовых из Telegram")
        Choice("Сервис", "stt_provider", listOf("groq" to "Groq", "openai" to "OpenAI"), "groq")
        PrefField("API-ключ сервиса расшифровки", "stt_key")

        SectionTitle("ИИ: текст → чёткая задача")
        Choice("Провайдер", "ai_provider", listOf("groq" to "Groq (бесплатно)", "claude" to "Claude", "openai" to "ChatGPT", "deepseek" to "DeepSeek"), "claude")
        PrefField("API-ключ (для Groq можно оставить пустым — возьмётся ключ расшифровки)", "ai_key")
        PrefField("Модель (пусто = по умолчанию)", "ai_model")
        PrefSwitch("Обрабатывать входящие через ИИ", "auto_ai", true)

        Text(
            "DeepSeek, Claude и ChatGPT работают только с пополненным балансом API. Groq даёт бесплатный лимит без карты.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Календарь")
        PrefSwitch("Задачи со временем → в календарь", "cal_write", true)

        Text(
            "Подробная инструкция — в файле README.md проекта.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
