package app.planner

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tg-sync", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )
        handleIntent(intent)
        setContent { PlannerTheme { App(tick.intValue) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** «Поделиться» из любого приложения → текст попадает в планировщик. */
    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Thread {
            val n = Planner.addFromText(t, "share")
            runOnUiThread { Toast.makeText(this, "Добавлено задач: $n", Toast.LENGTH_SHORT).show() }
        }.start()
    }
}

@Composable
fun PlannerTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    MaterialTheme(colorScheme = scheme, content = content)
}

fun today(): String = LocalDate.now().toString()

suspend fun toast(ctx: Context, s: String) =
    withContext(Dispatchers.Main) { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }

data class SyncResult(val msg: String, val added: Int, val error: Boolean)

/** Telegram + календарь. */
suspend fun fullSync(): SyncResult = withContext(Dispatchers.IO) {
    val parts = mutableListOf<String>()
    var added = 0
    var err = false
    if (Store.str("tg_token").isNotBlank()) {
        try {
            val n = Tg.sync(); added += n; parts.add("Telegram: +$n")
        } catch (e: Exception) {
            err = true; parts.add("Telegram: ошибка (${e.message?.take(80)})")
        }
    }
    if (Cal.has(Store.app)) {
        try {
            val n = Cal.pull(); added += n; parts.add("Календарь: +$n")
        } catch (e: Exception) {
            err = true; parts.add("Календарь: ошибка")
        }
    }
    SyncResult(
        if (parts.isEmpty()) "Подключите бота в настройках и разрешите доступ к календарю" else parts.joinToString("\n"),
        added, err
    )
}

val CAL_PERMS = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Refreshable(busy: Boolean, onRefresh: () -> Unit, content: @Composable () -> Unit) {
    PullToRefreshBox(isRefreshing = busy, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) { content() }
}

/**
 * Жесты навигации: свайп влево/вправо — предыдущий/следующий период;
 * щипок двумя пальцами — переключение месяц ↔ неделя ↔ день.
 */
@Composable
fun Modifier.navGestures(
    onPrev: () -> Unit, onNext: () -> Unit, onZoomOut: () -> Unit, onZoomIn: () -> Unit
): Modifier {
    val prev by rememberUpdatedState(onPrev)
    val next by rememberUpdatedState(onNext)
    val zoomOut by rememberUpdatedState(onZoomOut)
    val zoomIn by rememberUpdatedState(onZoomIn)
    return this
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                var zoom = 1f
                do {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.changes.size >= 2) {
                        zoom *= event.calculateZoom()
                        event.changes.forEach { it.consume() }
                    }
                } while (event.changes.any { it.pressed })
                if (zoom < 0.75f) zoomOut() else if (zoom > 1.35f) zoomIn()
            }
        }
        .pointerInput(Unit) {
            var total = 0f
            detectHorizontalDragGestures(
                onDragStart = { total = 0f },
                onDragEnd = { if (total > 200f) prev() else if (total < -200f) next() },
                onDragCancel = { total = 0f },
                onHorizontalDrag = { change, dx ->
                    total += dx
                    change.consume()
                }
            )
        }
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }          // 0 день, 1 неделя, 2 месяц, 3 туча, 4 настройки
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var creating by remember { mutableStateOf(false) }
    var newDate by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var asked by remember { mutableStateOf(false) }

    val doSync: (Boolean) -> Unit = { manual ->
        if (!busy) scope.launch {
            busy = true
            val r = fullSync()
            busy = false
            if (manual || r.error || r.added > 0) toast(ctx, r.msg)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { doSync(true) }
    val sync: () -> Unit = { if (Cal.has(ctx)) doSync(true) else perm.launch(CAL_PERMS) }
    LaunchedEffect(tick) {
        if (!Cal.has(ctx) && !asked) { asked = true; perm.launch(CAL_PERMS) } else doSync(false)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) {
            scope.launch(Dispatchers.IO) {
                val made = try { Planner.addFromTextDetailed(text, "voice") } catch (e: Exception) { emptyList() }
                toast(ctx, if (made.isNotEmpty()) "✅ " + made.joinToString("\n") { Planner.describe(it) } else "Не получилось добавить")
            }
        }
    }
    val startSpeech: () -> Unit = {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите задачу")
        try { speech.launch(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "На телефоне нет службы распознавания речи", Toast.LENGTH_LONG).show()
        }
    }

    val shift: (Long) -> Unit = { dir ->
        selected = when (tab) {
            0 -> selected.plusDays(dir)
            1 -> selected.plusWeeks(dir)
            2 -> selected.plusMonths(dir)
            else -> selected
        }
    }
    val zoomIn: () -> Unit = { if (tab == 2) tab = 1 else if (tab == 1) tab = 0 }
    val zoomOut: () -> Unit = { if (tab == 0) tab = 1 else if (tab == 1) tab = 2 }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val names = listOf("День", "Неделя", "Месяц", "Туча", "Настройки")
                val icons = listOf("📅", "🗓", "📆", "☁️", "⚙️")
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(n, maxLines = 1, fontSize = 11.sp) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab < 4) Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SmallFloatingActionButton(onClick = { startSpeech() }) { Text("🎤") }
                FloatingActionButton(onClick = {
                    newDate = if (tab < 3) selected.toString() else null
                    creating = true
                }) { Text("+", fontSize = 28.sp) }
            }
        }
    ) { pad ->
        val gm = if (tab < 3) Modifier.navGestures({ shift(-1) }, { shift(1) }, zoomOut, zoomIn) else Modifier
        Box(Modifier.padding(pad).fillMaxSize().then(gm)) {
            when (tab) {
                0 -> Refreshable(busy, sync) { DayScreen(selected, { selected = it }, busy, sync) { editing = it } }
                1 -> Refreshable(busy, sync) {
                    WeekScreen(selected, { selected = it }, onEdit = { editing = it }, onAdd = { d -> newDate = d; creating = true })
                }
                2 -> MonthScreen(selected, { selected = it }) { d -> selected = d; tab = 0 }
                3 -> Refreshable(busy, sync) { HeapScreen { editing = it } }
                else -> SettingsScreen()
            }
        }
    }

    if (creating) TaskDialog(null, newDate) { creating = false }
    editing?.let { t -> TaskDialog(t, null) { editing = null } }
}

@Composable
fun SectionTitle(s: String) = Text(
    s, Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary
)

fun srcLabel(s: String): String? = when (s) {
    "telegram" -> "✈️ Telegram"
    "telegram-voice" -> "✈️🎤 голосовое"
    "voice" -> "🎤 голос"
    "calendar" -> "📆 календарь"
    "share" -> "↗ из приложения"
    else -> null
}

@Composable
fun TaskRow(t: Task, onEdit: () -> Unit, date: String? = null, extra: @Composable (() -> Unit)? = null) {
    val done = Store.isDone(t, date ?: today())
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onEdit)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = done, onCheckedChange = { Planner.setDone(t, date, it) })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title, style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (done) TextDecoration.LineThrough else null
                )
                val meta = listOfNotNull(
                    t.time, t.repeat?.let { "🔁 " + Rep.label(it) }, t.category, srcLabel(t.source)
                ).joinToString(" · ")
                if (meta.isNotBlank()) Text(
                    meta, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            extra?.invoke()
        }
    }
}

// ───────────────────────── День ─────────────────────────
@Composable
fun DayScreen(sel: LocalDate, setSel: (LocalDate) -> Unit, busy: Boolean, sync: () -> Unit, onEdit: (Task) -> Unit) {
    val td = LocalDate.now()
    val ds = sel.toString()
    val list = Store.on(sel).sortedWith(compareBy<Task>({ Store.isDone(it, ds) }, { it.time ?: "99:99" }))
    val overdue = if (sel == td) {
        Store.tasks.filter { val d = it.date; it.repeat == null && d != null && d < ds && !it.done }.sortedBy { it.date }
    } else emptyList()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        sel.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("ru")))
                            .replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text("Осталось задач: ${list.count { !Store.isDone(it, ds) }}", style = MaterialTheme.typography.bodyMedium)
                }
                OutlinedButton(onClick = sync, enabled = !busy) { Text(if (busy) "…" else "⟳ Синхр.") }
            }
        }
        if (sel != td) item {
            TextButton(onClick = { setSel(td) }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("← К сегодняшнему дню") }
        }
        if (overdue.isNotEmpty()) {
            item { SectionTitle("Просрочено") }
            items(overdue, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = ds)) }) { Text("На сегодня") }
                }
            }
        }
        item { SectionTitle(if (sel == td) "Сегодня" else "Задачи на день") }
        if (list.isEmpty()) item { Text("Пока пусто. Загляните в Тучу.", Modifier.padding(16.dp)) }
        items(list, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }, ds) }
    }
}

// ───────────────────────── Неделя ─────────────────────────
@Composable
fun DayStrip(d: LocalDate, isOpen: Boolean, onToggle: () -> Unit, onEdit: (Task) -> Unit, onAdd: () -> Unit) {
    val ds = d.toString()
    val list = Store.on(d).sortedWith(compareBy<Task>({ Store.isDone(it, ds) }, { it.time ?: "99:99" }))
    val ru = Locale("ru")
    val label = d.dayOfWeek.getDisplayName(TextStyle.SHORT, ru).replaceFirstChar { it.uppercase() }.trimEnd('.') +
        ". " + d.format(DateTimeFormatter.ofPattern("dd.MM."))
    val colors = if (d == LocalDate.now()) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    else CardDefaults.cardColors()
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onToggle),
        colors = colors
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(label, Modifier.width(112.dp), style = MaterialTheme.typography.titleMedium)
                Column(Modifier.weight(1f)) {
                    if (list.isEmpty()) Text("Пока задач нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else if (!isOpen) {
                        list.take(3).forEach { t ->
                            Text(
                                listOfNotNull(t.time, t.title).joinToString(" "),
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textDecoration = if (Store.isDone(t, ds)) TextDecoration.LineThrough else null
                            )
                        }
                        if (list.size > 3) Text("и ещё ${list.size - 3}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(if (isOpen) "▲" else "▼")
            }
            if (isOpen) {
                list.forEach { t -> TaskRow(t, { onEdit(t) }, ds) }
                TextButton(onClick = onAdd) { Text("+ Задача на этот день") }
            }
        }
    }
}

@Composable
fun WeekScreen(sel: LocalDate, setSel: (LocalDate) -> Unit, onEdit: (Task) -> Unit, onAdd: (String) -> Unit) {
    val td = LocalDate.now()
    var open by remember { mutableStateOf(setOf(td.toString())) }
    val monday = sel.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val days = (0..6).map { monday.plusDays(it.toLong()) }
    val f = DateTimeFormatter.ofPattern("d.MM")
    val thisMonday = td.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { setSel(sel.minusWeeks(1)) }) { Text("‹", fontSize = 28.sp) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Неделя", style = MaterialTheme.typography.headlineSmall)
                    Text("${days.first().format(f)} – ${days.last().format(f)}", style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = { setSel(sel.plusWeeks(1)) }) { Text("›", fontSize = 28.sp) }
            }
        }
        if (monday != thisMonday) item {
            TextButton(onClick = { setSel(td) }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("К текущей неделе") }
        }
        items(days, key = { it.toString() }) { d ->
            val ds = d.toString()
            DayStrip(
                d, open.contains(ds),
                onToggle = { open = if (open.contains(ds)) open - ds else open + ds },
                onEdit = onEdit, onAdd = { onAdd(ds) }
            )
        }
    }
}

// ───────────────────────── Месяц ─────────────────────────
@Composable
fun MonthCell(d: LocalDate, isToday: Boolean, isSel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ds = d.toString()
    val n = Store.on(d).count { !Store.isDone(it, ds) }
    val bg = when {
        isToday -> MaterialTheme.colorScheme.primaryContainer
        isSel -> MaterialTheme.colorScheme.surfaceVariant
        else -> Color.Transparent
    }
    Column(
        modifier.padding(2.dp).clip(RoundedCornerShape(10.dp)).background(bg).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "${d.dayOfMonth}", style = MaterialTheme.typography.titleMedium,
            fontWeight = if (isToday) FontWeight.Bold else null
        )
        if (n > 0) Text(
            "•".repeat(minOf(n, 3)) + if (n > 3) "+" else "",
            color = MaterialTheme.colorScheme.primary, fontSize = 12.sp
        )
    }
}

@Composable
fun MonthScreen(sel: LocalDate, setSel: (LocalDate) -> Unit, openDay: (LocalDate) -> Unit) {
    val td = LocalDate.now()
    val ym = YearMonth.from(sel)
    val lead = ym.atDay(1).dayOfWeek.value - 1
    val len = ym.lengthOfMonth()
    val rows = (lead + len + 6) / 7
    val title = ym.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru"))
        .replaceFirstChar { it.uppercase() } + " " + ym.year
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { setSel(sel.minusMonths(1)) }) { Text("‹", fontSize = 28.sp) }
            Text(title, style = MaterialTheme.typography.headlineSmall)
            IconButton(onClick = { setSel(sel.plusMonths(1)) }) { Text("›", fontSize = 28.sp) }
        }
        if (ym != YearMonth.from(td)) TextButton(onClick = { setSel(td) }) { Text("К текущему месяцу") }
        Row(Modifier.fillMaxWidth()) {
            listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEach {
                Text(
                    it, Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth().height(62.dp)) {
                for (c in 0..6) {
                    val dayNum = r * 7 + c - lead + 1
                    if (dayNum in 1..len) {
                        val d = ym.atDay(dayNum)
                        MonthCell(d, d == td, d == sel, Modifier.weight(1f).fillMaxHeight()) { openDay(d) }
                    } else Spacer(Modifier.weight(1f))
                }
            }
        }
        Text(
            "Тап по дню — открыть день. Свайп — другой месяц. Щипок — к неделе и дню.",
            Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ───────────────────────── Туча ─────────────────────────
@Composable
fun HeapScreen(onEdit: (Task) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val td = today()
    val heap = Store.tasks.filter { it.date == null && it.repeat == null }
    val open = heap.filter { !it.done }
    val groups = open.groupBy { it.category ?: "Без категории" }.entries
        .sortedBy { if (it.key == "Без категории") "\uFFFF" else it.key }
    val done = heap.filter { it.done }
    var busy by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Туча", style = MaterialTheme.typography.headlineSmall)
                    Text("Задач без даты: ${open.size}", style = MaterialTheme.typography.bodyMedium)
                }
                if (Ai.enabled()) OutlinedButton(enabled = !busy, onClick = {
                    scope.launch(Dispatchers.IO) {
                        busy = true
                        try {
                            val todo = open.filter { it.category == null }.take(100)
                            val m = Ai.organize(todo)
                            m.forEach { (id, c) ->
                                Store.tasks.find { it.id == id }?.let { Planner.update(it.copy(category = c)) }
                            }
                            toast(ctx, "Разложено задач: ${m.size}")
                        } catch (e: Exception) {
                            val m = e.message ?: ""
                            toast(ctx, if (m.contains("402")) "ИИ: на балансе API-ключа нет денег. Выберите Groq — он бесплатный" else "ИИ: ${m.take(100)}")
                        }
                        busy = false
                    }
                }) { Text(if (busy) "…" else "🤖 Разобрать") }
            }
        }
        if (open.isEmpty()) item { Text("Туча пуста.", Modifier.padding(16.dp)) }
        groups.forEach { (cat, list) ->
            item(key = "h_$cat") { SectionTitle(cat) }
            items(list, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = td)) }) { Text("Сегодня") }
                }
            }
        }
        if (done.isNotEmpty()) {
            item(key = "h_done") { SectionTitle("Выполнено") }
            items(done, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }) }
        }
    }
}

fun pickDate(ctx: Context, cur: String?, set: (String) -> Unit) {
    val d = cur?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    DatePickerDialog(ctx, { _, y, m, day -> set(LocalDate.of(y, m + 1, day).toString()) },
        d.year, d.monthValue - 1, d.dayOfMonth).show()
}

fun pickTime(ctx: Context, set: (String) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> set("%02d:%02d".format(h, m)) }, 9, 0, true).show()
}

@Composable
fun TaskDialog(task: Task?, defaultDate: String?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(task?.title ?: "") }
    var notes by remember { mutableStateOf(task?.notes ?: "") }
    var cat by remember { mutableStateOf(task?.category ?: "") }
    var date by remember { mutableStateOf(task?.date ?: defaultDate) }
    var time by remember { mutableStateOf(task?.time) }
    var rep by remember { mutableStateOf(task?.repeat) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (task == null) "Новая задача" else "Задача") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Что сделать") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cat, { cat = it }, label = { Text("Категория") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pickDate(ctx, date) { date = it } }) { Text(date ?: "Дата") }
                    OutlinedButton(onClick = { pickTime(ctx) { time = it } }) { Text(time ?: "Время") }
                    if (date != null || time != null) TextButton(onClick = { date = null; time = null; rep = null }) { Text("✕") }
                }
                val base = date?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
                val wRule = "W:${base.dayOfWeek.value}"
                val mRule = "M:${base.dayOfMonth}"
                val yRule = "Y:%02d-%02d".format(base.monthValue, base.dayOfMonth)
                Text(rep?.let { "🔁 " + Rep.label(it) } ?: "Не повторяется", style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = rep == null, onClick = { rep = null }, label = { Text("Нет") })
                    FilterChip(selected = rep == "D", onClick = { rep = "D" }, label = { Text("День") })
                    FilterChip(selected = rep == wRule, onClick = { rep = wRule }, label = { Text("Неделя") })
                    FilterChip(selected = rep == mRule, onClick = { rep = mRule }, label = { Text("Месяц") })
                    FilterChip(selected = rep == yRule, onClick = { rep = yRule }, label = { Text("Год") })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    val r = rep
                    var d = date ?: if (time != null || r != null) today() else null
                    if (d != null && r != null) {
                        val ld = LocalDate.parse(d)
                        if (!Rep.occursOn(r, ld, ld)) d = Rep.firstFrom(r, ld).toString()
                    }
                    val base = task ?: Task(title = "")
                    Planner.update(
                        base.copy(
                            title = title.trim(), notes = notes, category = cat.trim().ifBlank { null },
                            date = d, time = if (d == null) null else time, repeat = r
                        )
                    )
                    onClose()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (task != null) TextButton(onClick = { Planner.delete(task); onClose() }) {
                    Text(if (task.repeat != null) "Удалить все повторы" else "Удалить")
                }
                TextButton(onClick = onClose) { Text("Отмена") }
            }
        }
    )
}

// ───────────────────────── Настройки ─────────────────────────
@Composable
fun PrefField(label: String, key: String) {
    var v by remember { mutableStateOf(Store.str(key)) }
    OutlinedTextField(
        v, { v = it; Store.put(key, it.trim()) },
        label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun Choice(title: String, key: String, options: List<Pair<String, String>>, default: String) {
    var cur by remember { mutableStateOf(Store.str(key, default)) }
    Text(title, style = MaterialTheme.typography.bodyMedium)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, l) ->
            FilterChip(selected = cur == v, onClick = { cur = v; Store.put(key, v) }, label = { Text(l) })
        }
    }
}

@Composable
fun PrefSwitch(label: String, key: String, default: Boolean) {
    var on by remember { mutableStateOf(Store.bool(key, default)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { on = it; Store.putBool(key, it) })
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val hint = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineSmall)

        SectionTitle("Telegram-бот")
        PrefField("Токен бота (от @BotFather)", "tg_token")
        PrefField("Chat ID (заполнится после первого сообщения боту)", "tg_chat")
        Button(onClick = { scope.launch { toast(ctx, fullSync().msg) } }) { Text("Проверить и забрать сообщения") }

        SectionTitle("Напоминания в Telegram")
        Text(
            "Бот пришлёт сообщение в ваш чат. Нужны токен и Chat ID (бот уже получил от вас сообщение).",
            style = MaterialTheme.typography.bodySmall, color = hint
        )
        PrefSwitch("Присылать напоминания", "tg_remind", true)
        Choice(
            "Когда напоминать о задаче со временем", "tg_lead",
            listOf("0" to "В момент", "10" to "За 10 мин", "30" to "За 30 мин", "60" to "За час"), "10"
        )
        PrefSwitch("Утренняя сводка дня", "tg_digest", true)
        PrefField("Время сводки (по умолчанию 08:00)", "tg_digest_time")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    val r = try { Tg.send("✅ Тест: напоминания работают"); "Отправлено" }
                    catch (e: Exception) { "Ошибка: ${e.message?.take(100)}" }
                    toast(ctx, r)
                }
            }) { Text("Тест") }
            OutlinedButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }) { Text("Точное время") }
        }
        val exact = ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        Text(
            if (exact) "Точные напоминания разрешены."
            else "Точные напоминания не разрешены: сообщения могут приходить с опозданием на несколько минут. Нажмите «Точное время» и включите переключатель.",
            style = MaterialTheme.typography.bodySmall, color = hint
        )

        SectionTitle("Расшифровка голосовых из Telegram")
        Choice("Сервис", "stt_provider", listOf("groq" to "Groq", "openai" to "OpenAI"), "groq")
        PrefField("API-ключ сервиса расшифровки", "stt_key")

        SectionTitle("ИИ: текст → чёткая задача")
        Choice("Провайдер", "ai_provider", listOf("groq" to "Groq (бесплатно)", "claude" to "Claude", "openai" to "ChatGPT", "deepseek" to "DeepSeek"), "claude")
        PrefField("API-ключ (для Groq можно оставить пустым — возьмётся ключ расшифровки)", "ai_key")
        PrefField("Модель (пусто = по умолчанию)", "ai_model")
        PrefSwitch("Обрабатывать входящие через ИИ", "auto_ai", true)
        Text(
            "DeepSeek, Claude и ChatGPT работают только с пополненным балансом API. Groq даёт бесплатный лимит без карты.",
            style = MaterialTheme.typography.bodySmall, color = hint
        )

        SectionTitle("Календарь")
        PrefSwitch("Задачи с датой → в календарь", "cal_write", true)
        PrefSwitch("Задачи без времени — на весь день", "cal_allday", true)

        Text("Подробная инструкция — в файле README.md проекта.", style = MaterialTheme.typography.bodySmall, color = hint)
    }
}
