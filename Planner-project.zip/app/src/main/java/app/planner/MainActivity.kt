package app.planner

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tg-sync", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )
        handleIntent(intent)
        setContent { PlannerTheme { App() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** «Поделиться» из любого приложения → текст попадает в планировщик. */
    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Thread {
            val n = Planner.addFromText(t, "share")
            runOnUiThread { Toast.makeText(this, "Добавлено задач: $n", Toast.LENGTH_SHORT).show() }
        }.start()
    }
}

@Composable
fun PlannerTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    MaterialTheme(colorScheme = scheme, content = content)
}

fun today(): String = LocalDate.now().toString()

suspend fun toast(ctx: Context, s: String) =
    withContext(Dispatchers.Main) { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }

/** Telegram + календарь. */
suspend fun fullSync(): String = withContext(Dispatchers.IO) {
    val parts = mutableListOf<String>()
    if (Store.str("tg_token").isNotBlank()) {
        parts.add(
            try { "Telegram: +${Tg.sync()}" }
            catch (e: Exception) { "Telegram: ошибка (${e.message?.take(80)})" }
        )
    }
    if (Cal.has(Store.app)) {
        parts.add(
            try { "Календарь: +${Cal.pull()}" }
            catch (e: Exception) { "Календарь: ошибка" }
        )
    }
    if (parts.isEmpty()) "Подключите бота в настройках и разрешите доступ к календарю" else parts.joinToString("\n")
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var creating by remember { mutableStateOf(false) }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) {
            scope.launch(Dispatchers.IO) {
                val n = try { Planner.addFromText(text, "voice") } catch (e: Exception) { 0 }
                toast(ctx, if (n > 0) "Добавлено задач: $n (без даты — в Куче)" else "Не получилось добавить")
            }
        }
    }
    val startSpeech = {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите задачу")
        try { speech.launch(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "На телефоне нет службы распознавания речи", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val names = listOf("Сегодня", "Куча", "Настройки")
                val icons = listOf("📅", "🗂", "⚙️")
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(n) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab < 2) Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SmallFloatingActionButton(onClick = { startSpeech() }) { Text("🎤") }
                FloatingActionButton(onClick = { creating = true }) { Text("+", fontSize = 28.sp) }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> TodayScreen { editing = it }
                1 -> HeapScreen { editing = it }
                else -> SettingsScreen()
            }
        }
    }

    if (creating) TaskDialog(null, if (tab == 0) today() else null) { creating = false }
    editing?.let { t -> TaskDialog(t, null) { editing = null } }
}

@Composable
fun SectionTitle(s: String) = Text(
    s, Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary
)

fun srcLabel(s: String): String? = when (s) {
    "telegram" -> "✈️ Telegram"
    "telegram-voice" -> "✈️🎤 голосовое"
    "voice" -> "🎤 голос"
    "calendar" -> "📆 календарь"
    "share" -> "↗ из приложения"
    else -> null
}

@Composable
fun TaskRow(t: Task, onEdit: () -> Unit, extra: @Composable (() -> Unit)? = null) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onEdit)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = t.done, onCheckedChange = { Planner.update(t.copy(done = it)) })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title, style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null
                )
                val meta = listOfNotNull(t.time, t.category, srcLabel(t.source)).joinToString(" · ")
                if (meta.isNotBlank()) Text(
                    meta, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            extra?.invoke()
        }
    }
}

@Composable
fun TodayScreen(onEdit: (Task) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val td = today()
    val todays = Store.tasks.filter { it.date == td }
        .sortedWith(compareBy<Task>({ it.done }, { it.time ?: "99:99" }))
    val overdue = Store.tasks.filter { val d = it.date; d != null && d < td && !it.done }.sortedBy { it.date }
    var busy by remember { mutableStateOf(false) }

    val run: () -> Unit = {
        scope.launch {
            busy = true
            val msg = fullSync()
            busy = false
            toast(ctx, msg)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { run() }
    LaunchedEffect(Unit) {
        if (Cal.has(ctx)) run()
        else perm.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("ru")))
                            .replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text("Осталось задач: ${todays.count { !it.done }}", style = MaterialTheme.typography.bodyMedium)
                }
                OutlinedButton(onClick = {
                    if (Cal.has(ctx)) run()
                    else perm.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
                }, enabled = !busy) { Text(if (busy) "…" else "⟳ Синхр.") }
            }
        }
        if (overdue.isNotEmpty()) {
            item { SectionTitle("Просрочено") }
            items(overdue, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = td)) }) { Text("На сегодня") }
                }
            }
        }
        item { SectionTitle("Сегодня") }
        if (todays.isEmpty()) item {
            Text("На сегодня пусто. Загляните в Кучу.", Modifier.padding(16.dp))
        }
        items(todays, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }) }
    }
}

@Composable
fun HeapScreen(onEdit: (Task) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val td = today()
    val heap = Store.tasks.filter { it.date == null }
    val open = heap.filter { !it.done }
    val groups = open.groupBy { it.category ?: "Без категории" }.entries
        .sortedBy { if (it.key == "Без категории") "\uFFFF" else it.key }
    val done = heap.filter { it.done }
    var busy by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Куча", style = MaterialTheme.typography.headlineSmall)
                    Text("Задач без даты: ${open.size}", style = MaterialTheme.typography.bodyMedium)
                }
                if (Ai.enabled()) OutlinedButton(enabled = !busy, onClick = {
                    scope.launch(Dispatchers.IO) {
                        busy = true
                        try {
                            val todo = open.filter { it.category == null }.take(100)
                            val m = Ai.organize(todo)
                            m.forEach { (id, c) ->
                                Store.tasks.find { it.id == id }?.let { Planner.update(it.copy(category = c)) }
                            }
                            toast(ctx, "Разложено задач: ${m.size}")
                        } catch (e: Exception) {
                            toast(ctx, "ИИ: ${e.message?.take(100)}")
                        }
                        busy = false
                    }
                }) { Text(if (busy) "…" else "🤖 Разобрать") }
            }
        }
        if (open.isEmpty()) item { Text("Куча пуста.", Modifier.padding(16.dp)) }
        groups.forEach { (cat, list) ->
            item(key = "h_$cat") { SectionTitle(cat) }
            items(list, key = { it.id }) { t ->
                TaskRow(t, { onEdit(t) }) {
                    TextButton(onClick = { Planner.update(t.copy(date = td)) }) { Text("Сегодня") }
                }
            }
        }
        if (done.isNotEmpty()) {
            item(key = "h_done") { SectionTitle("Выполнено") }
            items(done, key = { it.id }) { t -> TaskRow(t, { onEdit(t) }) }
        }
    }
}

fun pickDate(ctx: Context, cur: String?, set: (String) -> Unit) {
    val d = cur?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
    DatePickerDialog(ctx, { _, y, m, day -> set(LocalDate.of(y, m + 1, day).toString()) },
        d.year, d.monthValue - 1, d.dayOfMonth).show()
}

fun pickTime(ctx: Context, set: (String) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> set("%02d:%02d".format(h, m)) }, 9, 0, true).show()
}

@Composable
fun TaskDialog(task: Task?, defaultDate: String?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(task?.title ?: "") }
    var notes by remember { mutableStateOf(task?.notes ?: "") }
    var cat by remember { mutableStateOf(task?.category ?: "") }
    var date by remember { mutableStateOf(task?.date ?: defaultDate) }
    var time by remember { mutableStateOf(task?.time) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (task == null) "Новая задача" else "Задача") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Что сделать") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cat, { cat = it }, label = { Text("Категория") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pickDate(ctx, date) { date = it } }) { Text(date ?: "Дата") }
                    OutlinedButton(onClick = { pickTime(ctx) { time = it } }) { Text(time ?: "Время") }
                    if (date != null || time != null) TextButton(onClick = { date = null; time = null }) { Text("✕") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    val d = date ?: if (time != null) today() else null
                    val base = task ?: Task(title = "")
                    Planner.update(
                        base.copy(
                            title = title.trim(), notes = notes, category = cat.trim().ifBlank { null },
                            date = d, time = if (d == null) null else time
                        )
                    )
                    onClose()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (task != null) TextButton(onClick = { Planner.delete(task); onClose() }) { Text("Удалить") }
                TextButton(onClick = onClose) { Text("Отмена") }
            }
        }
    )
}

// ───────────────────────── Настройки ─────────────────────────
@Composable
fun PrefField(label: String, key: String) {
    var v by remember { mutableStateOf(Store.str(key)) }
    OutlinedTextField(
        v, { v = it; Store.put(key, it.trim()) },
        label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun Choice(title: String, key: String, options: List<Pair<String, String>>, default: String) {
    var cur by remember { mutableStateOf(Store.str(key, default)) }
    Text(title, style = MaterialTheme.typography.bodyMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, l) ->
            FilterChip(selected = cur == v, onClick = { cur = v; Store.put(key, v) }, label = { Text(l) })
        }
    }
}

@Composable
fun PrefSwitch(label: String, key: String, default: Boolean) {
    var on by remember { mutableStateOf(Store.bool(key, default)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { on = it; Store.putBool(key, it) })
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineSmall)

        SectionTitle("Telegram-бот")
        PrefField("Токен бота (от @BotFather)", "tg_token")
        PrefField("Chat ID (заполнится после первого сообщения боту)", "tg_chat")
        Button(onClick = { scope.launch { toast(ctx, fullSync()) } }) { Text("Проверить и забрать сообщения") }

        SectionTitle("Расшифровка голосовых из Telegram")
        Choice("Сервис", "stt_provider", listOf("groq" to "Groq", "openai" to "OpenAI"), "groq")
        PrefField("API-ключ сервиса расшифровки", "stt_key")

        SectionTitle("ИИ: текст → чёткая задача")
        Choice("Провайдер", "ai_provider", listOf("claude" to "Claude", "openai" to "ChatGPT", "deepseek" to "DeepSeek"), "claude")
        PrefField("API-ключ", "ai_key")
        PrefField("Модель (пусто = по умолчанию)", "ai_model")
        PrefSwitch("Обрабатывать входящие через ИИ", "auto_ai", true)

        SectionTitle("Календарь")
        PrefSwitch("Задачи со временем → в календарь", "cal_write", true)

        Text(
            "Подробная инструкция — в файле README.md проекта.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
