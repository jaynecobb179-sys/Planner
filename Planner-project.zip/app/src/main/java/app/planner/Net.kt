package app.planner

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import java.util.concurrent.TimeUnit

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    fun send(req: Request): String {
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}: ${s.take(200)}")
            return s
        }
    }

    fun postJson(url: String, body: String, headers: Map<String, String>): String {
        val rb = Request.Builder().url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
        headers.forEach { (k, v) -> rb.header(k, v) }
        return send(rb.build())
    }
}

// ───────────────────────── ИИ: Claude / OpenAI / DeepSeek ─────────────────────────
object Ai {
    data class Parsed(
        val title: String, val notes: String,
        val date: String?, val time: String?, val category: String?,
        val repeat: String? = null
    )

    /** Для Groq можно не вводить второй ключ: берётся тот же, что для голосовых. */
    fun key(): String {
        val k = Store.str("ai_key")
        return if (k.isBlank() && Store.str("ai_provider") == "groq") Store.str("stt_key") else k
    }

    fun enabled() = key().isNotBlank() && Store.bool("auto_ai", true)

    private fun ask(system: String, user: String): String {
        val key = key()
        val provider = Store.str("ai_provider", "claude")
        var model = Store.str("ai_model")
        if (provider == "claude") {
            if (model.isBlank()) model = "claude-haiku-5-5"
            val body = JSONObject()
                .put("model", model).put("max_tokens", 1500).put("system", system)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val resp = Net.postJson(
                "https://api.anthropic.com/v1/messages", body.toString(),
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
            )
            return JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        }
        val url: String
        when (provider) {
            "deepseek" -> {
                url = "https://api.deepseek.com/chat/completions"
                if (model.isBlank()) model = "deepseek-chat"
            }
            "groq" -> {
                url = "https://api.groq.com/openai/v1/chat/completions"
                if (model.isBlank()) model = "llama-3.3-70b-versatile"
            }
            else -> {
                url = "https://api.openai.com/v1/chat/completions"
                if (model.isBlank()) model = "gpt-4o-mini"
            }
        }
        val body = JSONObject().put("model", model).put(
            "messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user))
        )
        val resp = Net.postJson(url, body.toString(), mapOf("Authorization" to "Bearer $key"))
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun json(s: String): JSONObject =
        JSONObject(s.substring(s.indexOf('{'), s.lastIndexOf('}') + 1))

    private fun cleanDate(s: String?): String? = s?.let { runCatching { LocalDate.parse(it).toString() }.getOrNull() }
    private fun cleanTime(s: String?): String? =
        s?.let { runCatching { LocalTime.parse(it).format(DateTimeFormatter.ofPattern("HH:mm")) }.getOrNull() }

    /** Текст/расшифровка голосового → список чётких задач. */
    fun parse(text: String): List<Parsed> {
        val now = LocalDate.now()
        val dow = now.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("ru"))
        val sys = """Ты помощник-планировщик. Преврати сообщение пользователя в одну или несколько чётких задач.
Верни ТОЛЬКО JSON без пояснений: {"tasks":[{"title":"краткая формулировка, начинается с глагола","notes":"важные детали или пустая строка","date":"YYYY-MM-DD или null","time":"HH:MM или null","category":"одно-два слова или null","repeat":"код повторения или null"}]}
Сегодня $now, $dow. Слова «завтра», «в пятницу», «через неделю» переводи в конкретную дату. Если дата названа в начале или в любом месте сообщения («1 ноября», «26 октября») - это дата задачи. Если указаны день и месяц без года, а эта дата в текущем году уже прошла - бери следующий год. Если дата не названа - date=null. Если время не названо - time=null. Не выдумывай того, чего нет в сообщении. Пиши по-русски.
Повторение (repeat): если задача регулярная, дай код: D - каждый день; W:1,5 - по дням недели (1=пн ... 7=вс); M:25 - каждый месяц 25 числа (M:31 - последний день месяца); Y:11-01 - каждый год 1 ноября; E:14 - каждые 14 дней. Если повторения нет - null. Слова о повторении («ежемесячно», «по пятницам», «каждое 20-е число») в title не включай.
"""
        val arr = json(ask(sys, text)).getJSONArray("tasks")
        val out = mutableListOf<Parsed>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val title = o.optStr("title") ?: continue
            val date = cleanDate(o.optStr("date"))
            out.add(
                Parsed(
                    title, o.optString("notes", ""), date,
                    if (date != null) cleanTime(o.optStr("time")) else null,
                    o.optStr("category"),
                    o.optStr("repeat")?.takeIf { Rep.valid(it) }
                )
            )
        }
        return out
    }

    /** Раскладывает задачи из Кучи по категориям. Возвращает id → категория. */
    fun organize(items: List<Task>): Map<String, String> {
        val list = items.joinToString("\n") { "${it.id}|${it.title}" }
        val sys = """Разложи задачи по 3-8 коротким категориям (1-2 слова, по-русски, например: Работа, Дом, Покупки, Звонки, Здоровье, Финансы). Формат входа: id|задача.
Верни ТОЛЬКО JSON: {"items":[{"id":"...","category":"..."}]}. id не меняй."""
        val arr = json(ask(sys, list)).getJSONArray("items")
        val m = mutableMapOf<String, String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optStr("id") ?: continue
            val c = o.optStr("category") ?: continue
            m[id] = c
        }
        return m
    }
}

// ───────────────────────── Расшифровка голосовых (Whisper-совместимые API) ─────────────────────────
object Stt {
    fun enabled() = Store.str("stt_key").isNotBlank()

    fun transcribe(audio: ByteArray): String {
        val groq = Store.str("stt_provider", "groq") == "groq"
        val url = if (groq) "https://api.groq.com/openai/v1/audio/transcriptions"
        else "https://api.openai.com/v1/audio/transcriptions"
        val model = if (groq) "whisper-large-v3" else "whisper-1"
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("model", model)
            .addFormDataPart("language", "ru")
            .addFormDataPart("file", "voice.ogg", audio.toRequestBody("audio/ogg".toMediaType()))
            .build()
        val req = Request.Builder().url(url)
            .header("Authorization", "Bearer ${Store.str("stt_key")}")
            .post(body).build()
        return JSONObject(Net.send(req)).getString("text")
    }
}

// ───────────────────────── Telegram-бот ─────────────────────────
object Tg {
    private fun api(method: String) = "https://api.telegram.org/bot${Store.str("tg_token")}/$method"

    private fun getJson(url: String): JSONObject {
        val s = Net.send(Request.Builder().url(url).build())
        val j = JSONObject(s)
        if (!j.optBoolean("ok", false)) throw IOException(j.optString("description", "Telegram error"))
        return j
    }

    private fun reply(chat: Long, msg: String) {
        runCatching {
            getJson(api("sendMessage") + "?chat_id=$chat&text=" + URLEncoder.encode(msg, "UTF-8"))
        }
    }

    /** Сообщение в привязанный чат (бросает исключение при ошибке). */
    fun send(msg: String) {
        val chat = Store.str("tg_chat").toLongOrNull()
            ?: throw IOException("Chat ID пуст: напишите боту любое сообщение и нажмите «Проверить и забрать сообщения»")
        getJson(api("sendMessage") + "?chat_id=$chat&text=" + URLEncoder.encode(msg, "UTF-8"))
    }

    fun notify(msg: String) {
        runCatching { send(msg) }
    }

    private fun download(fileId: String): ByteArray {
        val path = getJson(api("getFile") + "?file_id=$fileId").getJSONObject("result").getString("file_path")
        val req = Request.Builder()
            .url("https://api.telegram.org/file/bot${Store.str("tg_token")}/$path").build()
        Net.http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return r.body!!.bytes()
        }
    }

    /** Забирает новые сообщения бота. Возвращает число добавленных задач. */
    fun sync(): Int {
        if (Store.str("tg_token").isBlank()) return 0
        val offset = Store.prefs.getLong("tg_offset", 0L)
        val res = getJson(
            api("getUpdates") + "?timeout=0&offset=$offset&allowed_updates=" +
                URLEncoder.encode("[\"message\"]", "UTF-8")
        ).getJSONArray("result")
        var next = offset
        var added = 0
        for (i in 0 until res.length()) {
            val u = res.getJSONObject(i)
            next = maxOf(next, u.getLong("update_id") + 1)
            try {
                val m = u.optJSONObject("message") ?: continue
                val chat = m.getJSONObject("chat").getLong("id")
                // Привязка к первому написавшему: чужие сообщения игнорируются
                val bound = Store.str("tg_chat")
                if (bound.isBlank()) Store.put("tg_chat", chat.toString())
                else if (bound != chat.toString()) continue

                var text: String? = (m.optStr("text") ?: m.optStr("caption"))
                var src = "telegram"
                val voice = m.optJSONObject("voice") ?: m.optJSONObject("audio")
                if (text == null && voice != null) {
                    if (!Stt.enabled()) {
                        reply(chat, "Голосовое получено, но нет ключа расшифровки. Добавьте его в настройках приложения.")
                        continue
                    }
                    text = Stt.transcribe(download(voice.getString("file_id")))
                    src = "telegram-voice"
                }
                if (text.isNullOrBlank()) continue
                if (text.startsWith("/")) {
                    reply(chat, "Пришлите текст или голосовое сообщение — добавлю задачу. Например: «ежемесячно 25-го отчёт по работе».")
                    continue
                }
                val made = Planner.addFromTextDetailed(text, src)
                added += made.size
                reply(
                    chat,
                    if (made.isEmpty()) "Не удалось добавить задачу"
                    else "✅ " + made.joinToString("\n") { Planner.describe(it) }
                )
            } catch (e: Exception) {
                // одно сломанное сообщение не должно блокировать остальные
            }
        }
        Store.prefs.edit().putLong("tg_offset", next).apply()
        return added
    }
}
