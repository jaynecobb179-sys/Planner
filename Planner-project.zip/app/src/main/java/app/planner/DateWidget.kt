package app.planner

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

/** Виджет 1×1 в виде значка календаря: день недели и число. Обновляется в полночь. */
class DateWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
    }

    override fun onEnabled(ctx: Context) {
        updateAll(ctx)
    }

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(tickIntent(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, TICK -> updateAll(ctx)
        }
    }

    companion object {
        private const val TICK = "app.planner.DATE_TICK"

        private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 7, Intent(ctx, DateWidget::class.java).setAction(TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun updateAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, DateWidget::class.java))
                if (ids.isEmpty()) return
                val open = PendingIntent.getActivity(
                    ctx, 8, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val rv = RemoteViews(ctx.packageName, R.layout.widget_date)
                rv.setImageViewBitmap(R.id.img, render())
                rv.setOnClickPendingIntent(R.id.img, open)
                mgr.updateAppWidget(ids, rv)
                scheduleMidnight(ctx)
            } catch (_: Exception) {
            }
        }

        private fun scheduleMidnight(ctx: Context) {
            val next = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault())
                .toInstant().toEpochMilli() + 3000
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(ctx))
        }

        private fun render(): Bitmap {
            val ru = Locale("ru")
            val s = 256
            val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val box = RectF(10f, 10f, 246f, 246f)
            val r = 52f
            p.color = Color.WHITE
            c.drawRoundRect(box, r, r, p)
            c.save()
            c.clipPath(Path().apply { addRoundRect(box, r, r, Path.Direction.CW) })
            p.color = Color.parseColor("#1A73E8")
            c.drawRect(10f, 10f, 246f, 92f, p)
            c.restore()
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = Color.parseColor("#33000000")
            c.drawRoundRect(box, r, r, p)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            val d = LocalDate.now()
            p.color = Color.WHITE
            p.textSize = 48f
            c.drawText(d.dayOfWeek.getDisplayName(TextStyle.SHORT, ru).uppercase(ru).trimEnd('.'), 128f, 66f, p)
            p.color = Color.parseColor("#202124")
            p.textSize = 124f
            c.drawText(d.dayOfMonth.toString(), 128f, 215f, p)
            return bmp
        }
    }
}
