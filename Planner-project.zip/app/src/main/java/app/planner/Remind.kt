package app.planner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Напоминания в Telegram: будильник системы будит приложение, оно шлёт сообщение через бота. */
object Remind {
    private const val REQ = 4242

    class Item(val at: Long, val digestDate: LocalDate?, val task: Task?)

    private fun leadMin(): Int = Store.str("tg_lead", "10").toIntOrNull() ?: 10

    private fun digestTime(): LocalTime {
        val m = Regex("(\\d{1,2})[:.](\\d{2})").find(Store.str("tg_digest_time"))
        val h = m?.groupValues?.get(1)?.toIntOrNull()
        val mm = m?.groupValues?.get(2)?.toIntOrNull()
        return if (h != null && mm != null && h in 0..23 && mm in 0..59) LocalTime.of(h, mm) else LocalTime.of(8, 0)
    }

    /** Напоминания, которые должны сработать в интервале (from, to]. */
    fun items(from: Long, to: Long): List<Item> {
        if (!Store.bool("tg_remind", true)) return emptyList()
        val zone = ZoneId.systemDefault()
        val out = mutableListOf<Item>()
        var d = Instant.ofEpochMilli(from).atZone(zone).toLocalDate().minusDays(1)
        val end = Instant.ofEpochMilli(to).atZone(zone).toLocalDate().plusDays(1)
        val lead = leadMin() * 60_000L
        while (!d.isAfter(end)) {
            val ds = d.toString()
            for (t in Store.on(d)) {
                val tm = t.time ?: continue
                if (Store.isDone(t, ds)) continue
                val at = LocalDateTime.of(d, LocalTime.parse(tm)).atZone(zone).toInstant().toEpochMilli() - lead
                if (at > from && at <= to) out.add(Item(at, null, t))
            }
            if (Store.bool("tg_digest", true)) {
                val at = LocalDateTime.of(d, digestTime()).atZone(zone).toInstant().toEpochMilli()
                if (at > from && at <= to) out.add(Item(at, d, null))
            }
            d = d.plusDays(1)
        }
        return out.sortedBy { it.at }
    }

    fun schedule(ctx: Context) {
        try {
            Store.init(ctx.applicationContext)
            val now = System.currentTimeMillis()
            val p = Store.prefs
            var last = p.getLong("rem_last", 0L)
            if (last == 0L) {
                last = now
                p.edit().putLong("rem_last", now).apply()
            }
            val from = maxOf(last, now - 12 * 3600_000L)
            val next = items(from, now + 48 * 3600_000L).firstOrNull()?.at
            val am = ctx.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(
                ctx, REQ, Intent(ctx, ReminderReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            if (next == null || Store.str("tg_token").isBlank()) {
                am.cancel(pi)
                return
            }
            val at = maxOf(next, now + 1500)
            try {
                if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: Exception) {
        }
    }

    /** Вызывается будильником: отправляет всё, что подошло по времени, и ставит следующий будильник. */
    fun fire(ctx: Context) {
        Store.init(ctx)
        val now = System.currentTimeMillis()
        val last = Store.prefs.getLong("rem_last", now)
        val from = maxOf(last, now - 12 * 3600_000L)
        val to = now + 5000
        val due = items(from, to)
        Store.prefs.edit().putLong("rem_last", to).apply()
        val lead = leadMin()
        val ru = Locale("ru")
        for (it in due) {
            val t = it.task
            if (t != null) {
                val whenTxt = if (lead == 0) "сейчас" else "через $lead мин"
                val rep = if (t.repeat != null) " 🔁" else ""
                Tg.notify("⏰ ${t.time} — ${t.title} ($whenTxt)$rep")
            } else {
                val d = it.digestDate ?: continue
                val ds = d.toString()
                val list = Store.on(d).filter { x -> !Store.isDone(x, ds) }.sortedBy { x -> x.time ?: "99:99" }
                if (list.isEmpty()) continue
                val head = if (d == LocalDate.now()) "сегодня" else d.format(DateTimeFormatter.ofPattern("d MMMM", ru))
                Tg.notify("📋 Задачи на $head:\n" + list.joinToString("\n") { x ->
                    "• " + (if (x.time != null) x.time + " " else "") + x.title
                })
            }
        }
        schedule(ctx)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pr = goAsync()
        val app = ctx.applicationContext
        Thread {
            try {
                Remind.fire(app)
            } finally {
                pr.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Remind.schedule(ctx.applicationContext)
        DateWidget.updateAll(ctx.applicationContext)
    }
}
