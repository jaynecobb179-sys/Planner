package app.planner

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * Правила повторения (строка в Task.repeat):
 *  D          — каждый день
 *  W:1,5      — по дням недели (1=пн ... 7=вс)
 *  M:25       — каждый месяц 25-го (31 = последний день месяца)
 *  Y:11-01    — каждый год 1 ноября
 *  E:14       — каждые 14 дней (от даты начала)
 */
object Rep {
    private val RU = Locale("ru")
    val monthsGen = listOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val validRe = Regex("^(D|W:[1-7](,[1-7])*|M:([1-9]|[12][0-9]|3[01])|Y:(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])|E:[0-9]{1,3})$")

    fun valid(r: String?): Boolean = r != null && validRe.matches(r)

    fun occursOn(rule: String, start: LocalDate, d: LocalDate): Boolean {
        if (d.isBefore(start)) return false
        return when {
            rule == "D" -> true
            rule.startsWith("W:") -> d.dayOfWeek.value in rule.substring(2).split(",").map { it.toInt() }
            rule.startsWith("M:") -> minOf(rule.substring(2).toInt(), d.lengthOfMonth()) == d.dayOfMonth
            rule.startsWith("Y:") -> {
                val p = rule.substring(2).split("-")
                val m = p[0].toInt()
                val dd = p[1].toInt()
                d.monthValue == m && (d.dayOfMonth == dd || (m == 2 && dd == 29 && !d.isLeapYear && d.dayOfMonth == 28))
            }
            rule.startsWith("E:") -> {
                val n = rule.substring(2).toLong()
                n > 0 && ChronoUnit.DAYS.between(start, d) % n == 0L
            }
            else -> false
        }
    }

    /** Первое срабатывание правила не раньше from. */
    fun firstFrom(rule: String, from: LocalDate): LocalDate {
        var d = from
        for (i in 0 until 800) {
            if (occursOn(rule, from, d)) return d
            d = d.plusDays(1)
        }
        return from
    }

    fun label(rule: String): String = when {
        rule == "D" -> "Каждый день"
        rule.startsWith("W:") -> {
            val ds = rule.substring(2).split(",").mapNotNull { it.toIntOrNull() }.sorted()
            when (ds) {
                listOf(1, 2, 3, 4, 5) -> "По будням"
                listOf(6, 7) -> "По выходным"
                else -> "По " + ds.joinToString(", ") { DayOfWeek.of(it).getDisplayName(TextStyle.SHORT, RU) }
            }
        }
        rule.startsWith("M:") -> {
            val n = rule.substring(2).toInt()
            if (n == 31) "Каждый месяц, в последний день" else "Каждый месяц, $n-го числа"
        }
        rule.startsWith("Y:") -> {
            val p = rule.substring(2).split("-")
            "Каждый год, ${p[1].toInt()} ${monthsGen[p[0].toInt() - 1]}"
        }
        rule.startsWith("E:") -> {
            val n = rule.substring(2).toInt()
            if (n % 7 == 0) "Каждые ${n / 7} нед." else "Каждые $n дн."
        }
        else -> rule
    }

    /** Правило для календаря Android (RRULE). */
    fun rrule(rule: String): String = when {
        rule == "D" -> "FREQ=DAILY"
        rule.startsWith("W:") -> "FREQ=WEEKLY;BYDAY=" + rule.substring(2).split(",").joinToString(",") {
            listOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")[it.toInt() - 1]
        }
        rule.startsWith("M:") -> {
            val n = rule.substring(2).toInt()
            "FREQ=MONTHLY;BYMONTHDAY=" + (if (n == 31) -1 else n)
        }
        rule.startsWith("Y:") -> "FREQ=YEARLY"
        rule.startsWith("E:") -> "FREQ=DAILY;INTERVAL=" + rule.substring(2)
        else -> "FREQ=DAILY"
    }
}
